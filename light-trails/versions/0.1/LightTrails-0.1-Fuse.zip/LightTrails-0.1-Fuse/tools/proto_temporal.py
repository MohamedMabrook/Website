# NumPy prototype of the LightTrails.fuse GPU passes (same math, same order).
import sys, numpy as np
from PIL import Image
from scipy.ndimage import map_coordinates, gaussian_filter

def samp(img, x, y):
    # bilinear, clamp, pixel coords (x,y) -> like _tex2DVecN with linear sampler
    H, W = img.shape[:2]
    xs = np.clip(x - 0.5, 0, W - 1); ys = np.clip(y - 0.5, 0, H - 1)
    if img.ndim == 2:
        return map_coordinates(img, [ys, xs], order=1, mode='nearest')
    return np.stack([map_coordinates(img[..., c], [ys, xs], order=1, mode='nearest') for c in range(img.shape[2])], -1)

def key(rgb, P):
    y = 0.2126*rgb[...,0] + 0.7152*rgb[...,1] + 0.0722*rgb[...,2]
    x = np.clip((y - P['thresh']) / P['soft'], 0, 1); k = x*x*(3-2*x)
    return np.concatenate([rgb*k[...,None], k[...,None]], -1)

def down(a, d):
    H, W = a.shape; h, w = H//d, W//d
    return a[:h*d, :w*d].reshape(h, d, w, d).mean((1, 3))

def flow(Kold, Knew, P):
    d = P['fdiv']
    bo = gaussian_filter(down(Kold, d), P['range']/d)
    bn = gaussian_filter(down(Knew, d), P['range']/d)
    g = 2*np.pi*(P['range']/d)**2; bo = bo*g; bn = bn*g   # same gain as the Fuse's down pass
    h, w = bo.shape
    yy, xx = np.mgrid[0:h, 0:w].astype(np.float32) + 0.5
    f = np.zeros((h, w, 2), np.float32)
    for it in range(P['iters']):
        wn = samp(bn, xx + f[...,0], yy + f[...,1])
        Ix = 0.5*((samp(bo, xx+1, yy) - samp(bo, xx-1, yy)) + (samp(bn, xx+f[...,0]+1, yy+f[...,1]) - samp(bn, xx+f[...,0]-1, yy+f[...,1])))*0.5
        Iy = 0.5*((samp(bo, xx, yy+1) - samp(bo, xx, yy-1)) + (samp(bn, xx+f[...,0], yy+f[...,1]+1) - samp(bn, xx+f[...,0], yy+f[...,1]-1)))*0.5
        It = wn - bo
        s = P['range']/d
        a = gaussian_filter(Ix*Ix, s); b = gaussian_filter(Ix*Iy, s); c = gaussian_filter(Iy*Iy, s)
        e1 = gaussian_filter(Ix*It, s); e2 = gaussian_filter(Iy*It, s)
        tr = a + c; det = a*c - b*b + 1e-4*tr*tr + 1e-20
        du = -(c*e1 - b*e2)/det; dv = -(a*e2 - b*e1)/det
        f[...,0] += du; f[...,1] += dv
        m = np.hypot(f[...,0], f[...,1]); lim = 2.5*s
        sc = np.where(m > lim, lim/np.maximum(m, 1e-9), 1); f *= sc[...,None]
    # confidence-weighted spread so in-between pixels know the motion
    conf = (bo + bn)
    s2 = P['range']/d
    num = np.stack([gaussian_filter(f[...,i]*conf, s2) for i in range(2)], -1)
    den = gaussian_filter(conf, s2) + 1e-6
    return (num/den[...,None]) * d  # full-res px per frame (old -> new)

def hash2(x, y, i):
    h = (x.astype(np.uint32)*np.uint32(73856093)) ^ (y.astype(np.uint32)*np.uint32(19349663)) ^ np.uint32(i*83492791 & 0xffffffff)
    h ^= h >> 13; h *= np.uint32(0x5bd1e995); h ^= h >> 15
    return (h & 0xFFFF).astype(np.float32)/65535.0

def render(frames, t, P):
    src = frames[t]; H, W, _ = src.shape
    yy, xx = np.mgrid[0:H, 0:W].astype(np.float32)
    px, py = xx + 0.5, yy + 0.5
    acc = np.zeros((H, W, 3), np.float32)
    N, S = P['frames'], P['quality']
    keys = {}
    def K(i):
        if i not in keys: keys[i] = key(frames[max(i, 0)], P)
        return keys[i]
    for k in range(1, N+1):
        Hk = K(t-k)
        v = flow(Hk[...,3], K(t-k+1)[...,3], P) if P['gapfill'] else np.zeros((H//P['fdiv'], W//P['fdiv'], 2))
        vx = samp(v[...,0], px/P['fdiv'], py/P['fdiv']); vy = samp(v[...,1], px/P['fdiv'], py/P['fdiv'])
        dvx, dvy = vx + P['driftx'], vy + P['drifty']
        m = np.hypot(dvx, dvy); ok = m > 0.05
        tx = np.where(ok, dvx/np.maximum(m,1e-6), 1.0); ty = np.where(ok, dvy/np.maximum(m,1e-6), 0.0)
        nx, ny = -ty, tx
        wk = P['decay']**(k-1)
        sub = np.zeros_like(acc)
        for s_i in range(S):
            j = hash2(xx, yy, k*31+s_i)
            s = (s_i + j)/S if P['gapfill'] else 0.0
            age = (k - 1 + s); a = age/N
            ph = P['phase'] + P['speed']*t
            wv = np.sin(2*np.pi*P['freq']*a - ph) + 0.45*np.sin(2*np.pi*P['freq']*2.3*a + 1.7*ph + 1.3)
            off = P['amp']*W*a*wv + (P['thick'] + P['spread']*a*W*0.01)*(2*hash2(xx, yy, k*977+s_i*13)-1)
            qx = px - s*vx - P['driftx']*age - nx*off
            qy = py - s*vy - P['drifty']*age - ny*off
            sub += samp(Hk[...,:3], qx, qy)
        acc += sub/S * wk
    tr = acc*P['gain']; tr[...,0] *= 1+0.5*P['warm']; tr[...,2] *= 1-0.5*P['warm']
    return np.clip(src + tr, 0, 1), np.clip(tr, 0, 1)

if __name__ == '__main__':
    ref = np.asarray(Image.open(sys.argv[1]).convert('RGB')).astype(np.float32)/255
    ref = np.asarray(Image.fromarray((ref*255).astype(np.uint8)).resize((1440, 675), Image.LANCZOS)).astype(np.float32)/255
    H, W, _ = ref.shape
    # synthetic camera push-in + slight pan + handheld sway: lights move outward and wobble
    frames = []
    yy, xx = np.mgrid[0:H, 0:W].astype(np.float32)
    for i in range(40):
        z = 1 + 0.012*i; ox = 4*i + 10*np.sin(i*0.4); oy = 6*np.sin(i*0.3)
        sx = (xx - W/2 - ox)/z + W/2; sy = (yy - H/2 - oy)/z + H/2
        frames.append(np.stack([map_coordinates(ref[...,c], [sy, sx], order=1, mode='nearest') for c in range(3)], -1))
    P = dict(thresh=0.72, soft=0.12, frames=16, decay=0.88, quality=6, gapfill=True,
             fdiv=4, range=24, iters=3, amp=0.006, freq=1.5, phase=0.0, speed=0.15,
             thick=1.0, spread=0.3, driftx=0.0, drifty=0.0, gain=1.0, warm=0.2)
    out, tr = render(frames, 39, P)
    Image.fromarray((out*255).astype(np.uint8)).save('out_gap.png')
    Image.fromarray((tr*255).astype(np.uint8)).save('tr_gap.png')
    Image.fromarray((frames[39]*255).astype(np.uint8)).save('src.png')
    P['gapfill'] = False
    out, tr = render(frames, 39, P)
    Image.fromarray((tr*255).astype(np.uint8)).save('tr_nogap.png')
