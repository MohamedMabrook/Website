# Runs LightTrails.fuse end to end: real Lua Process() via lupa, DCTL kernels compiled as C on CPU.
import sys, re, os, ctypes, subprocess, numpy as np
from PIL import Image
from lupa import LuaRuntime
from scipy.ndimage import map_coordinates

FUSE = sys.argv[1]
src_text = open(FUSE).read()
HDR = r'''
#include <math.h>
typedef struct { float x, y, z, w; } float4;
typedef struct { float x, y; } float2;
typedef struct { int w, h; float* d; } Tex;
static inline float4 to_float4(float a, float b, float c, float d){ float4 r={a,b,c,d}; return r; }
static inline float2 to_float2(float a, float b){ float2 r={a,b}; return r; }
static inline float4 texel(Tex* t, int x, int y){ if(x<0||y<0||x>=t->w||y>=t->h) return to_float4(0,0,0,0);
  float* p=t->d+4*(y*t->w+x); return to_float4(p[0],p[1],p[2],p[3]); }
static inline float4 _tex2DVecN(Tex* t, float u, float v, int m){
  float fx=u*t->w-0.5f, fy=v*t->h-0.5f; int x0=(int)floorf(fx), y0=(int)floorf(fy); float ax=fx-x0, ay=fy-y0;
  float4 a=texel(t,x0,y0), b=texel(t,x0+1,y0), c=texel(t,x0,y0+1), d=texel(t,x0+1,y0+1); float4 r;
  r.x=(a.x*(1-ax)+b.x*ax)*(1-ay)+(c.x*(1-ax)+d.x*ax)*ay; r.y=(a.y*(1-ax)+b.y*ax)*(1-ay)+(c.y*(1-ax)+d.y*ax)*ay;
  r.z=(a.z*(1-ax)+b.z*ax)*(1-ay)+(c.z*(1-ax)+d.z*ax)*ay; r.w=(a.w*(1-ax)+b.w*ax)*(1-ay)+(c.w*(1-ax)+d.w*ax)*ay; return r; }
static inline void _tex2DVec4Write(Tex* t, int x, int y, float4 v){ float* p=t->d+4*(y*t->w+x); p[0]=v.x;p[1]=v.y;p[2]=v.z;p[3]=v.w; }
#define __DEVICE__ static inline
#define __KERNEL__ static
#define __CONSTANTREF__ const
#define __TEXTURE2D__ Tex*
#define __TEXTURE2D_WRITE__ Tex*
#define _sinf sinf
#define _cosf cosf
#define _expf expf
#define _sqrtf sqrtf
#define _fabs fabsf
static int g_x, g_y;
#define DEFINE_KERNEL_ITERATORS_XY(a,b) int a=g_x, b=g_y;
'''

lua = LuaRuntime(unpack_returned_tuples=True)
G = lua.globals()
kernels = {}   # name -> (lib func, texnames, ctypes struct)
os.makedirs('build', exist_ok=True)

def ctype_struct(name, decl):
    fields = []
    for typ, nm in re.findall(r'(int|float)\s+(\w+)\s*;', decl):
        fields.append((nm, ctypes.c_int if typ == 'int' else ctypes.c_float))
    return type(name, (ctypes.Structure,), {'_fields_': fields})

def get_kernel(kname, ksrc, pname, pdecl):
    if kname in kernels: return kernels[kname]
    sig = re.search(r'__KERNEL__\s+void\s+' + kname + r'\s*\(([^)]*)\)', ksrc).group(1)
    texs = re.findall(r'__TEXTURE2D__\s+(\w+)', sig)
    code = HDR + 'typedef struct {' + pdecl + '} ' + pname + ';\n' + ksrc + '\n'
    code += 'void run(const %s* p, Tex** t, int W, int H){ for(g_y=0;g_y<H;g_y++) for(g_x=0;g_x<W;g_x++) %s(p, %s); }\n' % (
        pname, kname, ', '.join(['t[%d]' % i for i in range(len(texs) + 1)]))
    c = 'build/%s.c' % kname; so = 'build/%s.so' % kname
    open(c, 'w').write(code)
    r = subprocess.run(['gcc', '-O2', '-Wall', '-Wno-unused-function', '-Wno-unused-variable', '-shared', '-fPIC', '-o', so, c, '-lm'], capture_output=True, text=True)
    if r.returncode: print(r.stderr); raise SystemExit('compile failed: ' + kname)
    if r.stderr.strip(): print(kname, 'warnings:\n', r.stderr)
    lib = ctypes.CDLL(os.path.abspath(so))
    kernels[kname] = (lib.run, texs, ctype_struct(pname, pdecl))
    return kernels[kname]

class Img:
    def __init__(self, w, h, data=None):
        self.Width, self.Height, self.OriginalWidth = w, h, w
        self.data = data
def make_tex(img):
    if img.data is None: img.data = np.zeros((img.Height, img.Width, 4), np.float32)
    t = ctypes.c_int * 2
    class Tex(ctypes.Structure): _fields_ = [('w', ctypes.c_int), ('h', ctypes.c_int), ('d', ctypes.POINTER(ctypes.c_float))]
    return Tex(img.Width, img.Height, img.data.ctypes.data_as(ctypes.POINTER(ctypes.c_float))), Tex

def py_Image(attrs):
    like = attrs['IMG_Like']
    if like is not None: return Img(like.Width, like.Height)
    return Img(int(attrs['IMG_Width']), int(attrs['IMG_Height']))

class Node:
    def __init__(self, req, kname, ksrc, pname, pdecl):
        self.k = get_kernel(kname, ksrc, pname, pdecl); self.inputs = {}; self.out = None; self.params = None
    def GetParamBlock(self, decl): return lua.table()
    def SetParamBlock(self, p): self.params = p
    def AddSampler(self, *a): pass
    def AddInput(self, name, img): self.inputs[name] = img
    def AddOutput(self, name, img): self.out = img
    def GetErrorLog(self): return ''
    def RunSession(self, req):
        fn, texs, St = self.k
        ps = St(**{n: (int(self.params[n]) if t is ctypes.c_int else float(self.params[n])) for n, t in St._fields_})
        for n, _ in St._fields_:
            if self.params[n] is None: raise SystemExit('missing param %s' % n)
        objs = [make_tex(self.inputs[n]) for n in texs] + [make_tex(self.out)]
        arr = (ctypes.c_void_p * len(objs))(*[ctypes.addressof(o[0]) for o in objs])
        fn(ctypes.byref(ps), arr, self.out.Width, self.out.Height)
        return True

# synthetic shot (Fusion images are y-up: flip rows when converting)
ref = np.asarray(Image.open(sys.argv[2]).convert('RGB').resize((1440, 675), Image.LANCZOS)).astype(np.float32) / 255
H, W, _ = ref.shape
yy, xx = np.mgrid[0:H, 0:W].astype(np.float32)
def frame(i):
    i = max(i, 0)
    z = 1 + 0.004*i; ox = float(os.environ.get("PAN","4"))*i + 10*np.sin(i*0.4); oy = 6*np.sin(i*0.3)
    sx = (xx - W/2 - ox)/z + W/2; sy = (yy - H/2 - oy)/z + H/2
    f = np.stack([map_coordinates(ref[...,c], [sy, sx], order=1, mode='nearest') for c in range(3)] + [np.ones_like(xx)], -1)
    return Img(W, H, np.ascontiguousarray(f[::-1]))
cache = {}
def getf(i):
    if i not in cache: cache[i] = frame(i)
    return cache[i]

overrides = dict(a.split('=') for a in sys.argv[4:])
class Inp:
    def __init__(self, name, attrs): self.name = name; self.default = attrs['INP_Default']; self.val = None
    def GetValue(self, req):
        if self.name == 'Input': return getf(int(req.Time))
        v = float(overrides.get(self.name, self.default if self.default is not None else 0))
        return lua.table_from({'Value': v})
    def GetSource(self, t, flags): return getf(int(t))
result = {}
class Out:
    def Set(self, req, img): result['img'] = img
class Self:
    Comp = None
    def AddInput(self, name, id, attrs): return Inp(id, attrs)
    def AddOutput(self, *a): return Out()
    def BeginControlNest(self, *a): pass
    def EndControlNest(self): pass
class Req:
    def __init__(self, t): self.Time = t
    def GetFlags(self): return 0
    def IsQuick(self): return False
    def IsNoMotionBlur(self): return True

G.self = Self()
G.FuRegisterClass = lambda *a: None
G.Image = py_Image
G.DVIPComputeNode = lambda req, a, b, c, d: Node(req, a, b, c, d)
for c in ['CT_Tool', 'TEX_FILTER_MODE_LINEAR', 'TEX_ADDRESS_MODE_BORDER', 'TEX_NORMALIZED_COORDS_TRUE', 'IMDP_128bitFloat']:
    G[c] = 0
lua.execute(src_text)
lua.execute('Create()')
T = int(sys.argv[3])
G.Process(Req(T))
o = result['img'].data[::-1, :, :3]
Image.fromarray((np.clip(o, 0, 1)*255).astype(np.uint8)).save(os.environ.get('OUT','fuse_out.png'))
print('done', o.max(), 'kernel runs ok')
