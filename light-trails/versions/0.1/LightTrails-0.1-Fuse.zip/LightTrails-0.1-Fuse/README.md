# LightTrails.fuse

Wavy, smoky trails on the brightest highlights. Each trail follows its light's real motion: it's built from the keyed highlights of the previous N frames, so it points back along the path the light traveled. The gaps between frames get filled by estimating each light's motion and smearing every echo along it, so fast lights draw a continuous line instead of a row of beads.

All the pixel work runs on the GPU through Fusion's compute nodes (CUDA on your RTX card). The Lua side only fetches frames and launches the kernels.

## Install

1. Copy `LightTrails.fuse` to `%APPDATA%\Blackmagic Design\DaVinci Resolve\Support\Fusion\Fuses\`. Create the `Fuses` folder if it doesn't exist.
2. Restart Resolve.
3. Fusion page: Shift+Space, type "Light Trails". Or use Add Tool > Fuses > Light Trails.
4. Wire it `MediaIn > LightTrails > MediaOut`.

Errors print in the Fusion Console (Workspace > Console). After editing the file, click the tool's Reload button in the Inspector. No restart needed.

Placement: the Fusion page renders before the Color page, so the trails sit upstream of the whole grade, including Genesis. Set the threshold against the ungraded (log) image. Most log footage puts street lamps around 0.6 to 0.9, not the 0.8+ you'd see after a display transform.

## Workflow

1. Turn on **Show Highlight Key**. Raise **Threshold** until only the lamps stay white. Use **Softness** to feather the edge. Turn it off.
2. Set **Blend** to **Trails Only** while you tune, then switch back to **Add**.
3. **Frames** sets the trail length in time. **Decay** sets how fast it fades.
4. If fast lights look beaded, raise **Motion Range** to roughly the light's travel per frame in pixels, then raise **Gap Quality**.
5. Shape the look with Wave Amplitude, Frequency, Speed, Smoke and Spread.

## Controls

| Group | Control | What it does |
|---|---|---|
| Key | Threshold, Softness | Luma key on the highlights. Only the keyed light makes trails. |
| Key | Show Highlight Key | Shows the key as black and white. |
| Trail | Frames | Number of previous frames in the trail (1 to 48). |
| Trail | Decay | Brightness kept per frame of age. 0.85 means each older echo is 85% of the one before it. |
| Trail | Fill Gaps (motion) | Estimates each light's motion between frames and smears along it. Turn it off for a stepped, strobe look, or for speed. |
| Trail | Gap Quality | Smear samples per echo. More samples means a smoother line. |
| Trail | Motion Range px | Largest per-frame light movement the tracker can follow, in full-res pixels. |
| Trail | Motion Iterations | Tracker refinement passes. 3 is the default; 4 or 5 helps very fast lights. |
| Trail | Drift X/Y | Pushes the trail a fixed number of pixels per frame of age, like rising smoke. Gives static lights on a locked-off shot a trail. Positive Y is up. |
| Trail | Edge Bias | Favors lights near the left and right frame edges. Same as the DCTL. |
| Wave | Wave Amplitude px | Sideways wobble at the tail end. It ramps from zero at the light. |
| Wave | Wave Frequency | Wave cycles along the trail. |
| Wave | Phase, Speed | Phase offset, and how fast the wave travels down the trail over time. |
| Wave | Smoke, Smoke Scale | Low-frequency turbulence that grows with age. |
| Wave | Thickness, Spread | Base width, and extra width that grows with age. |
| Output | Warmth, Intensity, Blend | Same as the DCTL. Blend is Add, Screen or Trails Only. |

## Performance

The cost scales with Frames × Gap Quality at full resolution, plus a small motion pass per frame at about 960 px wide. At 4K, start with Frames 12 and Gap Quality 6. If playback drags, cache the node (right-click > Cache to Disk) or render it in place. Turning off Fill Gaps skips the motion pass entirely.

## Limits

- Motion tracking works on the blurred highlight key. Two lights crossing each other, or one light moving more than Motion Range per frame, can produce a wrong smear direction for that frame. The echoes stay in the right place, so the worst case is a short bead gap.
- Fuses run on the Fusion page, and on the Edit page through Fusion compositions. They can't load on the Color page. A Color page version would need an OpenFX plugin compiled in C++ for Windows.
- Frames before the clip's first frame repeat the first frame, so trails build up over the first N frames.

## Files

- `LightTrails.fuse`: the plugin.
- `tools/fuse_harness.py`: test harness. It runs the Fuse's real Lua `Process()` with the GPU kernels compiled as C on the CPU, on a synthetic moving shot. Run: `python tools/fuse_harness.py LightTrails.fuse reference/frame.png 39 Blend=2`. Needs `numpy scipy pillow lupa` and gcc.
- `tools/proto_temporal.py`: the NumPy prototype the kernels were ported from.
- `LightTrails.dctl`, `preview.py`: the original single-frame fallback, unchanged.
