import sys
import numpy as np
from PIL import Image

src, dst = sys.argv[1], sys.argv[2]
img = np.asarray(Image.open(src).convert("RGB")).astype(np.float32) / 255.0
H, W, _ = img.shape

p = dict(thresh=0.72, knee=0.12, trailLen=0.12, decay=2.0, amp=0.009, waves=1.6,
         phase=0.0, rise=6.0, thick=1.0, edge=0.9, gain=1.0, warm=0.2, steps=64)

def key(rgb):
    y = 0.2126 * rgb[..., 0] + 0.7152 * rgb[..., 1] + 0.0722 * rgb[..., 2]
    x = np.clip((y - p["thresh"]) / p["knee"], 0, 1)
    return x * x * (3 - 2 * x)

ys, xs = np.mgrid[0:H, 0:W].astype(np.float32)
h = (xs.astype(np.uint32) * np.uint32(73856093)) ^ (ys.astype(np.uint32) * np.uint32(19349663))
h ^= h >> 13; h *= np.uint32(0x5bd1e995); h ^= h >> 15
jit = (h & 0xFFFF).astype(np.float32) / 65535.0

DEG = np.pi / 180
side = np.where(xs < 0.5 * W, 1.0, -1.0)
dx = side * np.cos(p["rise"] * DEG)
dy = -np.sin(p["rise"] * DEG) * np.ones_like(xs)
nx, ny = -dy, dx
L, A, n = p["trailLen"] * W, p["amp"] * W, p["steps"]
acc = np.zeros_like(img)
K = key(img)

for i in range(n):
    u = (i + jit) / n
    s = u * L
    wv = np.sin(2*np.pi*p["waves"]*u + p["phase"]) + 0.45*np.sin(2*np.pi*p["waves"]*2.3*u - 1.7*p["phase"] + 1.3)
    off = A * u * wv + p["thick"] * ((i % 3) - 1)
    sx = xs - dx * s - nx * off
    sy = ys - dy * s - ny * off
    ix = np.floor(sx + 0.5).astype(int); iy = np.floor(sy + 0.5).astype(int)
    ok = (ix >= 0) & (iy >= 0) & (ix < W) & (iy < H)
    ixc, iyc = np.clip(ix, 0, W-1), np.clip(iy, 0, H-1)
    k = K[iyc, ixc] * ok
    e = np.abs(sx / W - 0.5) * 2
    wE = 1 - p["edge"] * (1 - e * e)
    w = np.exp(-p["decay"] * u) * k * wE
    acc += img[iyc, ixc] * w[..., None]

norm = p["gain"] * L / (n * 0.01 * W)
t = acc * norm
t[..., 0] *= 1 + 0.5 * p["warm"]; t[..., 2] *= 1 - 0.5 * p["warm"]
out = np.clip(img + t, 0, 1)
Image.fromarray((out * 255).astype(np.uint8)).save(dst)
Image.fromarray((np.clip(K, 0, 1) * 255).astype(np.uint8)).save(dst.replace(".png", "_key.png"))
print("max trail", t.max())
