# Light Trails 2.0: OpenFX for DaVinci Resolve (Windows, NVIDIA GPU)

Wavy, smoky trails that follow the motion of the hottest white lights, the street lamps and practicals from the reference frame. GPU only (CUDA).

## Install

1. Close Resolve.
2. Right-click `install.bat` and choose **Run as administrator**. It replaces any older version.
3. Color page: **Effects**, then **OpenFX**, then **Light Trails**. Put it on its own node before Genesis.

The **GPU** line at the bottom of the controls should read `CUDA (your NVIDIA GPU name)`. If it says `GPU unavailable`, the node passes the image through untouched; send me `%TEMP%\LightTrails.log`.

## Why 2.0 is light

1.x was heavy for three reasons, and all three are fixed:

| 1.x | 2.0 |
|---|---|
| Every render asked Resolve for 13 frames, so every slider move re-decoded and re-graded 12 old frames upstream | The previous frames stay on the GPU. After the first frame, a tweak or forward playback asks Resolve for 1 frame |
| Frames went GPU → CPU (Resolve) → CPU (convert) → GPU (plugin): about 3.5 GB of copying per 4K render | Uses Resolve's CUDA buffers directly, so frames never leave the GPU |
| Everything ran at full resolution | **Quality** sets the processing resolution; the image you see is always full resolution |

Measured on the test host, Intensity, Warmth and Blend only recomposite the finished trails, at about 1/100 the cost of a full render. Show Mask needs just the current frame.

## Quality

| Quality | Trail resolution | Samples | Frames read | Use it for |
|---|---|---|---|---|
| **Low** | 1/4 | 2 | every other frame | Setting the look. Reads a little brighter and softer than Final |
| **Medium** (default) | 1/2 | 4 | all | Normal grading |
| **High** | 3/4 | 6 | all | Checking detail |
| **Final** | full | 8 | all | The render |

Changing Quality resets the cache once. That costs one full fetch of history, then it's light again.

## Controls

- **Quality**, **Intensity**: at the top.
- **Highlights**
  - **Threshold**, **Softness**: how hot a light must be.
  - **Include Colored Lights**: off by default, so only white and warm-white lights trail and neon or brake lights don't.
  - **Show Mask**: shows exactly which lights will trail.
- **Trail**
  - **Length**: frames, up to 24.
  - **Decay**: how fast the trail fades.
  - **Drift X / Drift Y**: lets static lights trail on a locked-off shot.
- **Look**: **Wave**, **Wave Frequency**, **Wave Speed**, **Smoke**, **Width**, **Warmth**, **Blend**.
- **Depth** (collapsed)
  - **Depth Source**: Off, Depth Input or Alpha Channel.
  - **Depth From / Depth To**: the band of depth that trails.
  - **Depth Feather**: soft edge on the band.
  - **Invert Depth**: for maps with black = near.

Removed because they were slow or rarely useful: Fill Gaps (always on), Gap Quality and Motion Iterations (now set by Quality), Motion Range (automatic), Edge Bias (replaced by depth), Phase, Smoke Scale, Thickness and Spread (merged into Width), and the CPU/GPU switch.

## Depth

1. Make a depth map, for example with Resolve's **Depth Map** effect (white = near), on a separate node.
2. Connect it to Light Trails' second input and set **Depth Source** to **Depth Input**.
3. Turn on **Show Mask** and move **Depth From / Depth To** until only the lights you want stay white.

Resolve may not show a second node input for OpenFX on the Color page. In that case, use Light Trails on the Fusion page, where every input is exposed, or put the depth into the image's alpha and pick **Alpha Channel**.

To limit trails to part of the frame without depth, draw a window on the Light Trails node. Resolve applies the node's window to the effect for free.

## How it was tested

There's no NVIDIA GPU or Resolve on the build machine, so:

- **Kernel validity:** the GPU kernels assemble with NVIDIA's `ptxas` for Turing, Ampere, Ada and Hopper. RTX 50 cards take the same code through the driver.
- **Resolve's CUDA mode:** a test host emulates it, serving frames as padded GPU buffers on a CUDA stream. A mock NVIDIA driver checks every kernel argument against live memory, checks every argument size against the GPU code, and confirms nothing leaks.
- **Caching:** after the first frame, playback and tweaks ask the host for just 1 frame. Grade changes upstream reset the cache automatically, because the plugin fingerprints the current frame.
- **Consistency:** Windows and Linux builds, and CUDA mode and host-memory mode, produce bit-identical output. With no NVIDIA driver, the image passes through unchanged.

What's not yet proven is the real GPU's speed, and whether Resolve takes the CUDA path. If it doesn't, the plugin still works by uploading frames, but slower. `%TEMP%\LightTrails.log` records how many frames each render had to fetch.

## Building from source

`source/` contains the plugin, the patched OFX support library (`sdkpatch/`), the test host and the mock driver. See `build.sh`.
