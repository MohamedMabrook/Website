// LightTrailsCore.h
// GPU light trail engine. Works on Resolve's own CUDA buffers when the host provides them,
// or uploads host frames otherwise. Three caches keep interaction light:
//   frames : processing-res history frames (half float), keyed by time, checked by fingerprint
//   flows  : per-frame-pair motion fields
//   trails : the last finished trail buffer, so Intensity / Warmth / Blend only recomposite
#pragma once
#include <cstdint>
#include <functional>
#include <map>
#include <memory>
#include <mutex>
#include <string>
#include <vector>

#include "LightTrailsKernels.h"

namespace lt {

struct Img {
    int w = 0, h = 0;
    std::vector<float> d;   // RGBA float, row 0 = bottom, tightly packed
    void resize(int W, int H) { w = W; h = H; d.assign(size_t(W) * H * 4, 0.0f); }
    float* px(int x, int y) { return &d[(size_t(y) * w + x) * 4]; }
    const float* px(int x, int y) const { return &d[(size_t(y) * w + x) * 4]; }
};

enum Quality { Q_LOW = 0, Q_MEDIUM, Q_HIGH, Q_FINAL };
struct QualityPreset { float scale; int samples, iters, stride; };
QualityPreset qualityPreset(int q);

enum DepthMode { DEPTH_OFF = 0, DEPTH_INPUT = 1, DEPTH_ALPHA = 2 };

struct Params {
    int   quality = Q_MEDIUM;
    // highlights
    float thresh = 0.80f, soft = 0.10f;
    bool  colored = false;          // false: whites only
    bool  showMask = false;
    // depth
    int   depthMode = DEPTH_OFF;
    float dLo = 0.0f, dHi = 1.0f, dFeather = 0.05f;
    bool  dInvert = false;
    // trail
    float gain = 1.0f;
    int   frames = 12;
    float decay = 0.85f;
    float driftX = 0.0f, driftY = 0.0f;   // px per frame at full res, +Y up
    // look
    float amp = 20.0f, freq = 1.5f, speed = 0.15f, smoke = 0.5f, width = 10.0f;
    float warm = 0.2f;
    int   blend = 0;                // 0 add, 1 screen, 2 trails only
};

// An input image: either a CUDA buffer owned by the host, or a host-memory float image.
struct Frame {
    bool onDevice = false;
    ltk::View view = {nullptr, 0, 0, 0};
    const Img* host = nullptr;
    bool valid() const { return onDevice ? view.d != nullptr : host != nullptr; }
    int w() const { return onDevice ? view.w : (host ? host->w : 0); }
    int h() const { return onDevice ? view.h : (host ? host->h : 0); }
};

// Fetch the source (and depth) `back` frames before the current one. Images must stay valid
// until render() returns.
using FetchFn = std::function<bool(int back, Frame& img, Frame& depth)>;

struct Output {
    bool onDevice = false;
    ltk::View view = {nullptr, 0, 0, 0};   // device output (onDevice)
    Img* host = nullptr;                    // host output, same size as the source
    int offX = 0, offY = 0;                 // output pixel + off = source pixel
};

enum KernelId { K_RESAMPLE, K_FP, K_KEY, K_DOWN, K_BLUR, K_GRAD, K_SOLVE, K_PREP, K_SMOKE, K_SMEAR, K_COMP, K_COUNT };
extern const char* const kKernelNames[K_COUNT];

class Backend {
public:
    virtual ~Backend() {}
    virtual const std::string& name() const = 0;
    // stream: host CUDA stream or null. hint: a device pointer from the host (selects its context).
    virtual void begin(void* stream, const void* hint) = 0;
    virtual void end() = 0;
    virtual bool contextChanged() const = 0;
    virtual void* alloc(size_t bytes) = 0;
    virtual void release(void* p) = 0;
    virtual void upload(void* dst, const void* src, size_t bytes) = 0;
    virtual void download(void* dst, const void* src, size_t bytes) = 0;
    virtual void run(KernelId k, const void* args, int w, int h) = 0;
    virtual void sync() = 0;
};

std::unique_ptr<Backend> makeCudaBackend(std::string& err);

struct Stats { int fetched = 0, flowsSolved = 0, trailHit = 0, flushed = 0; };

class Engine {
public:
    explicit Engine(std::unique_ptr<Backend> b) : be_(std::move(b)) {}
    ~Engine();
    const std::string& backendName() const { return be_->name(); }

    // How many frames back the next render at `time` has to fetch (0 = all cached).
    int framesNeeded(double time, const Params& p, int W, int H, bool hasDepth);

    void render(const Frame& src, const Frame& depth, double time, float renderScale, const Params& p,
                const FetchFn& fetch, const Output& out, void* stream);

    Stats last;

private:
    struct Entry { uint64_t fp; ltk::HView img; };
    std::unique_ptr<Backend> be_;
    std::mutex mtx_;
    std::map<size_t, std::vector<void*>> pool_;
    std::map<int64_t, Entry> frames_;
    uint64_t frameSig_ = 0;
    std::map<uint64_t, ltk::View> flows_;
    std::vector<uint64_t> flowOrder_;
    uint64_t trailKey_ = 0;
    ltk::View trail_ = {nullptr, 0, 0, 0};

    void* getBytes(size_t n);
    void putBytes(void* p, size_t n);
    ltk::View getV(int w, int h);
    void putV(const ltk::View& v);
    ltk::HView getH(int w, int h);
    void putH(const ltk::HView& v);
    void flushAll();
    void forgetAll();
    static uint64_t frameSig(int W, int H, const Params& p, bool hasDepth);
};

void logLine(const std::string& s);   // appends to %TEMP%\LightTrails.log

} // namespace lt
