// LightTrailsCuda.cpp: CUDA backend through the NVIDIA driver API (nvcuda.dll, loaded at runtime).
// When Resolve renders in CUDA mode we run in the context that owns its buffers, on its stream.
#include "LightTrailsCore.h"

#include <cstdlib>
#include <cstring>
#include <map>
#include <stdexcept>
#include <string>

#ifdef _WIN32
#  include <windows.h>
#else
#  include <dlfcn.h>
#endif

#include "LightTrails_ptx.h"   // generated: static const char kLightTrailsPtx[]

namespace lt {
namespace {

typedef int CUresult;
typedef int CUdevice;
typedef void* CUcontext;
typedef void* CUmodule;
typedef void* CUfunction;
typedef void* CUstream;
typedef unsigned long long CUdeviceptr;

struct Api {
    CUresult (*cuInit)(unsigned);
    CUresult (*cuDeviceGetCount)(int*);
    CUresult (*cuDeviceGet)(CUdevice*, int);
    CUresult (*cuDeviceGetName)(char*, int, CUdevice);
    CUresult (*cuDevicePrimaryCtxRetain)(CUcontext*, CUdevice);
    CUresult (*cuCtxPushCurrent)(CUcontext);
    CUresult (*cuCtxPopCurrent)(CUcontext*);
    CUresult (*cuCtxGetCurrent)(CUcontext*);
    CUresult (*cuPointerGetAttribute)(void*, int, CUdeviceptr);
    CUresult (*cuModuleLoadDataEx)(CUmodule*, const void*, unsigned, int*, void**);
    CUresult (*cuModuleGetFunction)(CUfunction*, CUmodule, const char*);
    CUresult (*cuMemAlloc)(CUdeviceptr*, size_t);
    CUresult (*cuMemFree)(CUdeviceptr);
    CUresult (*cuMemcpyHtoD)(CUdeviceptr, const void*, size_t);
    CUresult (*cuMemcpyDtoH)(void*, CUdeviceptr, size_t);
    CUresult (*cuLaunchKernel)(CUfunction, unsigned, unsigned, unsigned, unsigned, unsigned, unsigned,
                               unsigned, CUstream, void**, void**);
    CUresult (*cuStreamSynchronize)(CUstream);
    CUresult (*cuCtxSynchronize)();
    CUresult (*cuGetErrorString)(CUresult, const char**);
};

const int CU_POINTER_ATTRIBUTE_CONTEXT = 1;

class CudaBackend : public Backend {
public:
    bool init(std::string& err)
    {
        const char* over = getenv("LT_CUDA_LIB");   // test hook
#ifdef _WIN32
        lib_ = (void*)LoadLibraryA(over ? over : "nvcuda.dll");
        if (!lib_) { err = "nvcuda.dll not found (NVIDIA driver missing?)"; return false; }
#else
        lib_ = dlopen(over ? over : "libcuda.so.1", RTLD_NOW | RTLD_LOCAL);
        if (!lib_) { err = std::string("libcuda not found: ") + dlerror(); return false; }
#endif
#define LOAD(field, name) if (!(*(void**)&api_.field = sym(name))) { err = std::string("driver lacks ") + name; return false; }
        LOAD(cuInit, "cuInit");
        LOAD(cuDeviceGetCount, "cuDeviceGetCount");
        LOAD(cuDeviceGet, "cuDeviceGet");
        LOAD(cuDeviceGetName, "cuDeviceGetName");
        LOAD(cuDevicePrimaryCtxRetain, "cuDevicePrimaryCtxRetain");
        LOAD(cuCtxPushCurrent, "cuCtxPushCurrent_v2");
        LOAD(cuCtxPopCurrent, "cuCtxPopCurrent_v2");
        LOAD(cuCtxGetCurrent, "cuCtxGetCurrent");
        LOAD(cuPointerGetAttribute, "cuPointerGetAttribute");
        LOAD(cuModuleLoadDataEx, "cuModuleLoadDataEx");
        LOAD(cuModuleGetFunction, "cuModuleGetFunction");
        LOAD(cuMemAlloc, "cuMemAlloc_v2");
        LOAD(cuMemFree, "cuMemFree_v2");
        LOAD(cuMemcpyHtoD, "cuMemcpyHtoD_v2");
        LOAD(cuMemcpyDtoH, "cuMemcpyDtoH_v2");
        LOAD(cuLaunchKernel, "cuLaunchKernel");
        LOAD(cuStreamSynchronize, "cuStreamSynchronize");
        LOAD(cuCtxSynchronize, "cuCtxSynchronize");
        LOAD(cuGetErrorString, "cuGetErrorString");
#undef LOAD
        try {
            ck(api_.cuInit(0), "cuInit");
            int n = 0;
            ck(api_.cuDeviceGetCount(&n), "cuDeviceGetCount");
            if (n < 1) { err = "no CUDA device"; return false; }
            ck(api_.cuDeviceGet(&dev_, 0), "cuDeviceGet");
            char nm[256] = {0};
            api_.cuDeviceGetName(nm, sizeof nm - 1, dev_);
            name_ = std::string("CUDA (") + nm + ")";
            ck(api_.cuDevicePrimaryCtxRetain(&primary_, dev_), "cuDevicePrimaryCtxRetain");
            // compile the kernels now so a bad driver shows up in Status, not mid-render
            ck(api_.cuCtxPushCurrent(primary_), "cuCtxPushCurrent");
            std::string e;
            bool ok = loadModule(primary_, e);
            CUcontext c; api_.cuCtxPopCurrent(&c);
            if (!ok) { err = e; return false; }
        } catch (const std::exception& e) {
            err = e.what();
            return false;
        }
        return true;
    }

    const std::string& name() const override { return name_; }

    void begin(void* stream, const void* hint) override
    {
        stream_ = stream;
        CUcontext ctx = nullptr;
        if (hint) api_.cuPointerGetAttribute(&ctx, CU_POINTER_ATTRIBUTE_CONTEXT, (CUdeviceptr)hint);
        if (!ctx) api_.cuCtxGetCurrent(&ctx);
        if (!ctx) ctx = primary_;
        ck(api_.cuCtxPushCurrent(ctx), "cuCtxPushCurrent");
        changed_ = (ctx_ != nullptr && ctx != ctx_);
        ctx_ = ctx;
        std::string e;
        if (!mods_.count(ctx) && !loadModule(ctx, e)) {
            CUcontext c; api_.cuCtxPopCurrent(&c);
            throw std::runtime_error(e);
        }
        fn_ = mods_[ctx].data();
    }
    void end() override { CUcontext c; api_.cuCtxPopCurrent(&c); }
    bool contextChanged() const override { return changed_; }

    void* alloc(size_t n) override
    {
        CUdeviceptr p = 0;
        ck(api_.cuMemAlloc(&p, n), "cuMemAlloc (out of GPU memory? try a lower Quality)");
        return reinterpret_cast<void*>(p);
    }
    void release(void* p) override { api_.cuMemFree(reinterpret_cast<CUdeviceptr>(p)); }
    void upload(void* d, const void* s, size_t n) override
    {
        sync();   // the buffer may still be read by queued kernels
        ck(api_.cuMemcpyHtoD(reinterpret_cast<CUdeviceptr>(d), s, n), "cuMemcpyHtoD");
    }
    void download(void* d, const void* s, size_t n) override
    {
        sync();
        ck(api_.cuMemcpyDtoH(d, reinterpret_cast<CUdeviceptr>(s), n), "cuMemcpyDtoH");
    }
    void run(KernelId k, const void* args, int w, int h) override
    {
        const unsigned bx = 16, by = 16;
        void* params[1] = {const_cast<void*>(args)};
        ck(api_.cuLaunchKernel(fn_[k], (w + bx - 1) / bx, (h + by - 1) / by, 1, bx, by, 1, 0,
                               (CUstream)stream_, params, nullptr), kKernelNames[k]);
    }
    void sync() override
    {
        if (stream_) ck(api_.cuStreamSynchronize((CUstream)stream_), "cuStreamSynchronize");
        else ck(api_.cuCtxSynchronize(), "cuCtxSynchronize");
    }

private:
    void* lib_ = nullptr;
    Api api_ = {};
    CUdevice dev_ = 0;
    CUcontext primary_ = nullptr, ctx_ = nullptr;
    bool changed_ = false;
    void* stream_ = nullptr;
    std::map<CUcontext, std::vector<CUfunction>> mods_;
    CUfunction* fn_ = nullptr;
    std::string name_ = "CUDA";

    void* sym(const char* n)
    {
#ifdef _WIN32
        return (void*)GetProcAddress((HMODULE)lib_, n);
#else
        return dlsym(lib_, n);
#endif
    }
    bool loadModule(CUcontext ctx, std::string& err)
    {
        static char log[8192];
        log[0] = 0;
        int opt[2] = {5 /*CU_JIT_ERROR_LOG_BUFFER*/, 6 /*CU_JIT_ERROR_LOG_BUFFER_SIZE_BYTES*/};
        void* val[2] = {log, (void*)(size_t)sizeof log};
        CUmodule mod = nullptr;
        CUresult r = api_.cuModuleLoadDataEx(&mod, kLightTrailsPtx, 2, opt, val);
        if (r != 0) { err = "GPU kernel compile failed: " + errStr(r) + " " + log; return false; }
        std::vector<CUfunction> f(K_COUNT);
        for (int k = 0; k < K_COUNT; ++k)
            if (api_.cuModuleGetFunction(&f[k], mod, kKernelNames[k]) != 0) { err = std::string("missing kernel ") + kKernelNames[k]; return false; }
        mods_[ctx] = f;
        return true;
    }
    std::string errStr(CUresult r)
    {
        const char* s = nullptr;
        if (api_.cuGetErrorString) api_.cuGetErrorString(r, &s);
        return std::string(s ? s : "unknown") + " (" + std::to_string(r) + ")";
    }
    void ck(CUresult r, const char* what)
    {
        if (r != 0) throw std::runtime_error(std::string(what) + ": " + errStr(r));
    }
};

} // namespace

std::unique_ptr<Backend> makeCudaBackend(std::string& err)
{
    std::unique_ptr<CudaBackend> b(new CudaBackend());
    if (!b->init(err)) return nullptr;
    return std::unique_ptr<Backend>(b.release());
}

} // namespace lt
