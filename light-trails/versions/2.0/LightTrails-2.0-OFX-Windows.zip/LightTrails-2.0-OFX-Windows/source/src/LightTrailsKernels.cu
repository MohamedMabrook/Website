// LightTrailsKernels.cu: CUDA entry points. Built to PTX with clang (see build.sh) and
// embedded in the plugin; the NVIDIA driver JIT-compiles it for the installed GPU.
#define __global__ __attribute__((global))
#include "LightTrailsKernels.h"

#define LT_IDX \
    int x = __nvvm_read_ptx_sreg_ctaid_x() * __nvvm_read_ptx_sreg_ntid_x() + __nvvm_read_ptx_sreg_tid_x(); \
    int y = __nvvm_read_ptx_sreg_ctaid_y() * __nvvm_read_ptx_sreg_ntid_y() + __nvvm_read_ptx_sreg_tid_y();
#define LT_K(name, T, fn, W, H) \
    __global__ void name(ltk::T a) { LT_IDX if (x < a.W && y < a.H) ltk::fn(x, y, a); }

extern "C" {
LT_K(gResample, ResampleArgs, kResample, dst.w, dst.h)
LT_K(gFp,       FpArgs,       kFp,       dst.w, dst.h)
LT_K(gKey,      KeyArgs,      kKey,      dst.w, dst.h)
LT_K(gDown,     DownArgs,     kDown,     dst.w, dst.h)
LT_K(gBlur,     BlurArgs,     kBlur,     dst.w, dst.h)
LT_K(gGrad,     GradArgs,     kGrad,     dst.w, dst.h)
LT_K(gSolve,    SolveArgs,    kSolve,    dst.w, dst.h)
LT_K(gPrep,     PrepArgs,     kPrep,     dst.w, dst.h)
LT_K(gSmoke,    SmokeArgs,    kSmoke,    dst.w, dst.h)
LT_K(gSmear,    SmearArgs,    kSmear,    acc.w, acc.h)
LT_K(gComp,     CompArgs,     kComp,     dst.w, dst.h)
}
