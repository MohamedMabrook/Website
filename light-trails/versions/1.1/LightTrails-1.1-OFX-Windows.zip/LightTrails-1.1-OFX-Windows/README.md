# Light Trails 1.1: OpenFX plugin for DaVinci Resolve (Windows, CUDA)

A Color page plugin. Wavy, smoky trails on the brightest highlights, and each trail follows its light's real motion across the previous frames. It renders on your NVIDIA GPU through CUDA, and falls back to the CPU automatically if CUDA isn't available.

## Install

1. Close Resolve.
2. Right-click `install.bat` and choose **Run as administrator**. It copies `LightTrails.ofx.bundle` to `C:\Program Files\Common Files\OFX\Plugins\`, replacing 1.0 if it's there.
3. Open Resolve. On the Color page, open **Effects**, then **OpenFX**, then **Light Trails**, and drag it onto its own node before Genesis.

## Check that it's on the GPU

Open the node's **Device** group and look at **Status**:

- `CUDA (your NVIDIA GPU name)`: it's rendering on the GPU.
- `CPU (GPU failed: ...)`: CUDA couldn't start. The reason follows "GPU failed:", and the full log is in `%TEMP%\LightTrails.log`. Send me that file.
- `CPU (GPU off)`: **Use GPU (CUDA)** is unchecked.

If the GPU fails partway through a render, the plugin finishes that frame on the CPU and stays on the CPU for that node. Reopen the project to retry the GPU.

## What the GPU build does

- **Kernels:** all nine passes (key, downsample, blur, motion gradients, motion solve, flow spread, smoke field, smear, composite) run as CUDA kernels.
- **No CUDA install needed:** the kernels ship inside the plugin as PTX. Your NVIDIA driver compiles them for your GPU the first time the plugin loads, which can add a second or two once. The PTX targets sm_75, so any driver from the last several years accepts it.
- **Memory:** about 1.2 GB of VRAM at 4K with 12 frames.
- **Motion cache:** motion fields live on the GPU between frames. Sequential playback solves one new frame pair per frame instead of twelve.

Expected speed at 4K is roughly 0.15 to 0.4 s per frame. Most of that is moving frames between Resolve's memory and the GPU, not the trail math. This estimate is extrapolated, not measured; see the testing notes below. Turn on the node cache for real-time playback.

## First pass

1. Turn on **Show Highlight Key**. Raise **Threshold** until only the lamps stay white, then turn it off.
2. Set **Blend** to **Trails Only** while tuning, then switch back to **Add**.
3. **Frames** sets the trail length in time. **Decay** sets how fast it fades.
4. If fast lights look beaded, raise **Motion Range** (roughly the light's travel per frame, in pixels), then **Gap Quality**.

The controls match the Fuse. One change from the Fuse and from 1.0: the smoke turbulence uses a new noise pattern that gives identical results on CPU and GPU. It's the same kind of motion, with different swirls.

## How it was tested

There's no NVIDIA GPU or Resolve on the build machine, so the GPU path was tested in layers:

1. **Kernel math:** the kernels are written once in `LightTrailsKernels.h` and compiled both as CUDA and as CPU code. The CPU build matches 1.0 to 0.000015 (smoke off), and 1.0 matched the Fuse to 1/255.
2. **PTX validity:** NVIDIA's `ptxas` 12.4 assembles the shipped PTX for sm_75, sm_86, sm_89 and sm_90. That's Turing through Hopper; RTX 50 series takes the same PTX through the driver.
3. **Argument layout:** every kernel's parameter block is the same size in the PTX, the Linux build and the Windows build: 40, 40, 48, 72, 72, 64, 32, 160 and 80 bytes.
4. **GPU orchestration:** a mock NVIDIA driver (`tests/mock_cuda.cpp`) stands in for `nvcuda.dll` and runs every launch on the CPU. It checks that every pointer handed to a kernel is live device memory big enough for its image, that contexts are pushed and popped in pairs, and that nothing leaks. The Windows plugin under Wine went through 366 launches per frame with no violations. Its output matched the CPU path bit for bit, and sequential renders matched cold renders.
5. **Fallback:** with no NVIDIA driver present, the Windows build reports why in Status and renders on the CPU.

What this can't prove is the real GPU running the PTX. That's the first thing to confirm on your machine.

## If it doesn't show up or fails

- **Not in the OpenFX list:** check the folder path above, then restart Resolve. If it's still missing, close Resolve, delete `OFXPluginCacheV2.xml` (it's under a `Blackmagic Design\DaVinci Resolve\Support` folder in `%APPDATA%` or `C:\ProgramData`), and reopen.
- **Status shows CPU:** send `%TEMP%\LightTrails.log`.
- **Red node or crash:** send that log plus the newest file in `%APPDATA%\Blackmagic Design\DaVinci Resolve\Support\logs\`. Uncheck **Use GPU (CUDA)** to keep working on the CPU in the meantime.

## Building from source

`source/` has everything. You need Linux, clang 18 (for CUDA to PTX), `mingw-w64`, and the OFX SDK at `OFX_Release_1_4_TAG`:

```bash
OFX_SDK=/path/to/openfx PTXAS=/path/to/ptxas ./build.sh windows
```

`./build.sh linux` plus `./build_host.sh linux` build a native plugin and test host. To run the GPU path against the mock driver, set `LT_CUDA_LIB` to the mock library.
