// LightTrailsCuda.cpp: CUDA backend through the NVIDIA driver API.
// The driver (nvcuda.dll, installed with every NVIDIA driver) is loaded at runtime and the
// embedded PTX is JIT-compiled for the installed GPU, so no CUDA toolkit or runtime DLL is needed.
#include "LightTrailsCore.h"

#include <cstring>
#include <stdexcept>
#include <string>

#ifdef _WIN32
#  include <windows.h>
#else
#  include <dlfcn.h>
#endif

#include "LightTrails_ptx.h"   // generated: static const char kLightTrailsPtx[]

namespace lt {
namespace {

typedef int CUresult;
typedef int CUdevice;
typedef void* CUcontext;
typedef void* CUmodule;
typedef void* CUfunction;
typedef void* CUstream;
typedef unsigned long long CUdeviceptr;
typedef int CUjit_option;

struct Api {
    CUresult (*cuInit)(unsigned);
    CUresult (*cuDeviceGetCount)(int*);
    CUresult (*cuDeviceGet)(CUdevice*, int);
    CUresult (*cuDeviceGetName)(char*, int, CUdevice);
    CUresult (*cuDevicePrimaryCtxRetain)(CUcontext*, CUdevice);
    CUresult (*cuDevicePrimaryCtxRelease)(CUdevice);
    CUresult (*cuCtxPushCurrent)(CUcontext);
    CUresult (*cuCtxPopCurrent)(CUcontext*);
    CUresult (*cuModuleLoadDataEx)(CUmodule*, const void*, unsigned, CUjit_option*, void**);
    CUresult (*cuModuleUnload)(CUmodule);
    CUresult (*cuModuleGetFunction)(CUfunction*, CUmodule, const char*);
    CUresult (*cuMemAlloc)(CUdeviceptr*, size_t);
    CUresult (*cuMemFree)(CUdeviceptr);
    CUresult (*cuMemcpyHtoD)(CUdeviceptr, const void*, size_t);
    CUresult (*cuMemcpyDtoH)(void*, CUdeviceptr, size_t);
    CUresult (*cuLaunchKernel)(CUfunction, unsigned, unsigned, unsigned, unsigned, unsigned, unsigned,
                               unsigned, CUstream, void**, void**);
    CUresult (*cuCtxSynchronize)();
    CUresult (*cuGetErrorString)(CUresult, const char**);
};

void* openLib(std::string& err)
{
    const char* over = getenv("LT_CUDA_LIB");             // test hook
#ifdef _WIN32
    HMODULE h = LoadLibraryA(over ? over : "nvcuda.dll");
    if (!h) err = "nvcuda.dll not found (no NVIDIA driver?)";
    return (void*)h;
#else
    void* h = dlopen(over ? over : "libcuda.so.1", RTLD_NOW | RTLD_LOCAL);
    if (!h) err = std::string("libcuda not found: ") + dlerror();
    return h;
#endif
}

void* sym(void* lib, const char* name)
{
#ifdef _WIN32
    return (void*)GetProcAddress((HMODULE)lib, name);
#else
    return dlsym(lib, name);
#endif
}

class CudaBackend : public Backend {
public:
    bool init(std::string& err)
    {
        lib_ = openLib(err);
        if (!lib_) return false;
#define LOAD(field, name) if (!(*(void**)&api_.field = sym(lib_, name))) { err = std::string("missing ") + name; return false; }
        LOAD(cuInit, "cuInit");
        LOAD(cuDeviceGetCount, "cuDeviceGetCount");
        LOAD(cuDeviceGet, "cuDeviceGet");
        LOAD(cuDeviceGetName, "cuDeviceGetName");
        LOAD(cuDevicePrimaryCtxRetain, "cuDevicePrimaryCtxRetain");
        LOAD(cuDevicePrimaryCtxRelease, "cuDevicePrimaryCtxRelease");
        LOAD(cuCtxPushCurrent, "cuCtxPushCurrent_v2");
        LOAD(cuCtxPopCurrent, "cuCtxPopCurrent_v2");
        LOAD(cuModuleLoadDataEx, "cuModuleLoadDataEx");
        LOAD(cuModuleUnload, "cuModuleUnload");
        LOAD(cuModuleGetFunction, "cuModuleGetFunction");
        LOAD(cuMemAlloc, "cuMemAlloc_v2");
        LOAD(cuMemFree, "cuMemFree_v2");
        LOAD(cuMemcpyHtoD, "cuMemcpyHtoD_v2");
        LOAD(cuMemcpyDtoH, "cuMemcpyDtoH_v2");
        LOAD(cuLaunchKernel, "cuLaunchKernel");
        LOAD(cuCtxSynchronize, "cuCtxSynchronize");
        LOAD(cuGetErrorString, "cuGetErrorString");
#undef LOAD
        try {
            ck(api_.cuInit(0), "cuInit");
            int n = 0;
            ck(api_.cuDeviceGetCount(&n), "cuDeviceGetCount");
            if (n < 1) { err = "no CUDA device"; return false; }
            ck(api_.cuDeviceGet(&dev_, 0), "cuDeviceGet");
            char nm[256] = {0};
            api_.cuDeviceGetName(nm, sizeof nm - 1, dev_);
            name_ = std::string("CUDA (") + nm + ")";
            ck(api_.cuDevicePrimaryCtxRetain(&ctx_, dev_), "cuDevicePrimaryCtxRetain");
            haveCtx_ = true;
            begin();
            // JIT the PTX, capturing the driver's error log if it fails
            static char log[8192];
            log[0] = 0;
            CUjit_option opt[2] = {5 /*CU_JIT_ERROR_LOG_BUFFER*/, 6 /*CU_JIT_ERROR_LOG_BUFFER_SIZE_BYTES*/};
            void* val[2] = {log, (void*)(size_t)sizeof log};
            CUresult r = api_.cuModuleLoadDataEx(&mod_, kLightTrailsPtx, 2, opt, val);
            if (r != 0) { end(); err = "PTX load failed: " + errStr(r) + " " + log; return false; }
            for (int k = 0; k < K_COUNT; ++k)
                ck(api_.cuModuleGetFunction(&fn_[k], mod_, kKernelNames[k]), kKernelNames[k]);
            end();
        } catch (const std::exception& e) {
            err = e.what();
            return false;
        }
        return true;
    }

    ~CudaBackend() override
    {
        if (!lib_) return;
        if (haveCtx_) {
            api_.cuCtxPushCurrent(ctx_);
            if (mod_) api_.cuModuleUnload(mod_);
            CUcontext c;
            api_.cuCtxPopCurrent(&c);
            api_.cuDevicePrimaryCtxRelease(dev_);
        }
        // the driver library stays loaded: unloading nvcuda inside a host process is unsafe
    }

    const std::string& name() const override { return name_; }

    void begin() override { ck(api_.cuCtxPushCurrent(ctx_), "cuCtxPushCurrent"); }
    void end() override { CUcontext c; api_.cuCtxPopCurrent(&c); }

    ltk::View alloc(int w, int h) override
    {
        CUdeviceptr p = 0;
        ck(api_.cuMemAlloc(&p, size_t(w) * h * 16), "cuMemAlloc");
        ltk::View v;
        v.d = reinterpret_cast<float*>(p);
        v.w = w; v.h = h;
        return v;
    }
    void release(const ltk::View& v) override { api_.cuMemFree(reinterpret_cast<CUdeviceptr>(v.d)); }
    void upload(const ltk::View& v, const Img& s) override
    {
        ck(api_.cuMemcpyHtoD(reinterpret_cast<CUdeviceptr>(v.d), s.d.data(), size_t(v.w) * v.h * 16), "cuMemcpyHtoD");
    }
    void download(const ltk::View& v, Img& d) override
    {
        d.resize(v.w, v.h);
        ck(api_.cuMemcpyDtoH(d.d.data(), reinterpret_cast<CUdeviceptr>(v.d), size_t(v.w) * v.h * 16), "cuMemcpyDtoH");
    }
    void run(KernelId k, const void* args, int w, int h) override
    {
        const unsigned bx = 16, by = 16;
        void* params[1] = {const_cast<void*>(args)};
        ck(api_.cuLaunchKernel(fn_[k], (w + bx - 1) / bx, (h + by - 1) / by, 1, bx, by, 1, 0, nullptr, params, nullptr),
           kKernelNames[k]);
    }

private:
    void* lib_ = nullptr;
    Api api_ = {};
    CUdevice dev_ = 0;
    CUcontext ctx_ = nullptr;
    bool haveCtx_ = false;
    CUmodule mod_ = nullptr;
    CUfunction fn_[K_COUNT] = {};
    std::string name_ = "CUDA";

    std::string errStr(CUresult r)
    {
        const char* s = nullptr;
        if (api_.cuGetErrorString) api_.cuGetErrorString(r, &s);
        return std::string(s ? s : "unknown") + " (" + std::to_string(r) + ")";
    }
    void ck(CUresult r, const char* what)
    {
        if (r != 0) throw std::runtime_error(std::string(what) + ": " + errStr(r));
    }
};

} // namespace

std::unique_ptr<Backend> makeCudaBackend(std::string& err)
{
    std::unique_ptr<CudaBackend> b(new CudaBackend());
    if (!b->init(err)) return nullptr;
    return std::unique_ptr<Backend>(b.release());
}

} // namespace lt
