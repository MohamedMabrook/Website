// LightTrailsKernels.cu: CUDA entry points. Built to PTX with clang (see build.sh) and
// embedded in the plugin; the NVIDIA driver JIT-compiles it for the installed GPU.
#define __global__ __attribute__((global))
#include "LightTrailsKernels.h"

#define LT_IDX \
    int x = __nvvm_read_ptx_sreg_ctaid_x() * __nvvm_read_ptx_sreg_ntid_x() + __nvvm_read_ptx_sreg_tid_x(); \
    int y = __nvvm_read_ptx_sreg_ctaid_y() * __nvvm_read_ptx_sreg_ntid_y() + __nvvm_read_ptx_sreg_tid_y();

extern "C" {
__global__ void gKey(ltk::KeyArgs a)     { LT_IDX if (x < a.dst.w && y < a.dst.h) ltk::kKey(x, y, a); }
__global__ void gDown(ltk::DownArgs a)   { LT_IDX if (x < a.dst.w && y < a.dst.h) ltk::kDown(x, y, a); }
__global__ void gBlur(ltk::BlurArgs a)   { LT_IDX if (x < a.dst.w && y < a.dst.h) ltk::kBlur(x, y, a); }
__global__ void gGrad(ltk::GradArgs a)   { LT_IDX if (x < a.dst.w && y < a.dst.h) ltk::kGrad(x, y, a); }
__global__ void gSolve(ltk::SolveArgs a) { LT_IDX if (x < a.dst.w && y < a.dst.h) ltk::kSolve(x, y, a); }
__global__ void gPrep(ltk::PrepArgs a)   { LT_IDX if (x < a.dst.w && y < a.dst.h) ltk::kPrep(x, y, a); }
__global__ void gSmoke(ltk::SmokeArgs a) { LT_IDX if (x < a.dst.w && y < a.dst.h) ltk::kSmoke(x, y, a); }
__global__ void gSmear(ltk::SmearArgs a) { LT_IDX if (x < a.acc.w && y < a.acc.h) ltk::kSmear(x, y, a); }
__global__ void gComp(ltk::CompArgs a)   { LT_IDX if (x < a.dst.w && y < a.dst.h) ltk::kComp(x, y, a); }
}
