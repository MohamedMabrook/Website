// LightTrailsCore.cpp: render pipeline (backend-agnostic) + CPU backend.
#include "LightTrailsCore.h"

#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <stdexcept>
#include <thread>

namespace lt {

const char* const kKernelNames[K_COUNT] = {"gKey", "gDown", "gBlur", "gGrad", "gSolve", "gPrep", "gSmoke", "gSmear", "gComp"};

void parallelRows(int h, const std::function<void(int, int)>& fn)
{
    unsigned n = std::max(1u, std::thread::hardware_concurrency());
    n = std::min<unsigned>(n, (unsigned)std::max(1, h / 4));
    if (n <= 1) { fn(0, h); return; }
    std::vector<std::thread> th;
    th.reserve(n);
    for (unsigned i = 0; i < n; ++i) {
        int y0 = int((int64_t)h * i / n), y1 = int((int64_t)h * (i + 1) / n);
        th.emplace_back([&fn, y0, y1] { fn(y0, y1); });
    }
    for (auto& t : th) t.join();
}

void logLine(const std::string& s)
{
    static std::mutex m;
    std::lock_guard<std::mutex> l(m);
    const char* dir = getenv("TEMP");
    if (!dir) dir = getenv("TMPDIR");
    if (!dir) dir = "/tmp";
    std::string path = std::string(dir) + "/LightTrails.log";
    FILE* f = fopen(path.c_str(), "a");
    if (!f) return;
    time_t t = time(nullptr);
    char ts[32];
    strftime(ts, sizeof ts, "%Y-%m-%d %H:%M:%S", localtime(&t));
    fprintf(f, "[%s] %s\n", ts, s.c_str());
    fclose(f);
}

// ---------------------------------------------------------------------------------------
// CPU backend: runs the shared per-pixel kernels over all rows on every core
// ---------------------------------------------------------------------------------------
namespace {
class CpuBackend : public Backend {
public:
    const std::string& name() const override { static const std::string n("CPU"); return n; }
    ltk::View alloc(int w, int h) override
    {
        ltk::View v;
        v.d = new float[size_t(w) * h * 4]();
        v.w = w; v.h = h;
        return v;
    }
    void release(const ltk::View& v) override { delete[] v.d; }
    void upload(const ltk::View& v, const Img& s) override { std::memcpy(v.d, s.d.data(), size_t(v.w) * v.h * 16); }
    void download(const ltk::View& v, Img& d) override { d.resize(v.w, v.h); std::memcpy(d.d.data(), v.d, size_t(v.w) * v.h * 16); }

    template <typename A, typename F>
    static void loop(const void* args, int w, int h, F f)
    {
        const A& a = *static_cast<const A*>(args);
        parallelRows(h, [&](int y0, int y1) {
            for (int y = y0; y < y1; ++y)
                for (int x = 0; x < w; ++x) f(x, y, a);
        });
    }
    void run(KernelId k, const void* a, int w, int h) override
    {
        switch (k) {
            case K_KEY:   loop<ltk::KeyArgs>(a, w, h, ltk::kKey); break;
            case K_DOWN:  loop<ltk::DownArgs>(a, w, h, ltk::kDown); break;
            case K_BLUR:  loop<ltk::BlurArgs>(a, w, h, ltk::kBlur); break;
            case K_GRAD:  loop<ltk::GradArgs>(a, w, h, ltk::kGrad); break;
            case K_SOLVE: loop<ltk::SolveArgs>(a, w, h, ltk::kSolve); break;
            case K_PREP:  loop<ltk::PrepArgs>(a, w, h, ltk::kPrep); break;
            case K_SMOKE: loop<ltk::SmokeArgs>(a, w, h, ltk::kSmoke); break;
            case K_SMEAR: loop<ltk::SmearArgs>(a, w, h, ltk::kSmear); break;
            case K_COMP:  loop<ltk::CompArgs>(a, w, h, ltk::kComp); break;
            default: throw std::runtime_error("bad kernel id");
        }
    }
};
} // namespace

std::unique_ptr<Backend> makeCpuBackend() { return std::unique_ptr<Backend>(new CpuBackend()); }

// ---------------------------------------------------------------------------------------
// Engine
// ---------------------------------------------------------------------------------------
Engine::~Engine()
{
    try {
        be_->begin();
        clearPool();
        for (auto& kv : flow_) be_->release(kv.second);
        flow_.clear();
        be_->end();
    } catch (...) {}
}

ltk::View Engine::get(int w, int h)
{
    auto it = pool_.find(std::make_pair(w, h));
    if (it != pool_.end()) { ltk::View v = it->second; pool_.erase(it); return v; }
    return be_->alloc(w, h);
}

void Engine::put(const ltk::View& v) { pool_.insert(std::make_pair(std::make_pair(v.w, v.h), v)); }

void Engine::clearPool()
{
    for (auto& kv : pool_) be_->release(kv.second);
    pool_.clear();
}

void Engine::cachePut(uint64_t key, const ltk::View& v, size_t cap)
{
    flow_[key] = v;
    lru_.push_front(key);
    while (lru_.size() > cap) {
        auto it = flow_.find(lru_.back());
        if (it != flow_.end()) { put(it->second); flow_.erase(it); }
        lru_.pop_back();
    }
}

static inline uint64_t mix(uint64_t h, uint64_t v) { h ^= v + 0x9e3779b97f4a7c15ull + (h << 6) + (h >> 2); return h; }

// Sparse fingerprint of a host frame (about 1 in 61 pixels). Identifies the frame content for
// the motion cache, so changing an upstream grade or the clip never serves a stale field.
static uint64_t fingerprint(const Img& im)
{
    uint64_t h = 1469598103934665603ull ^ ((uint64_t)im.w << 32) ^ (uint64_t)im.h;
    const size_t n = im.d.size();
    for (size_t i = 0; i < n; i += 61 * 4 + 1) {
        uint32_t v; std::memcpy(&v, &im.d[i], 4);
        h = (h ^ v) * 1099511628211ull;
    }
    return h;
}

void Engine::render(const Img& src, double time, float ps, const Params& p, const FetchFn& fetch, Img& out)
{
    struct Scope {
        Backend& b; explicit Scope(Backend& x) : b(x) { b.begin(); } ~Scope() { b.end(); }
    } scope(*be_);

    const int W = src.w, H = src.h;
    if (W != poolW_ || H != poolH_) {          // resolution changed: drop everything
        clearPool();
        for (auto& kv : flow_) be_->release(kv.second);
        flow_.clear(); lru_.clear();
        poolW_ = W; poolH_ = H;
    }

    std::vector<ltk::View> scratch;           // returned to the pool at the end
    auto tmp = [&](int w, int h) { ltk::View v = get(w, h); scratch.push_back(v); return v; };
    struct Ret { Engine* e; std::vector<ltk::View>* s; ~Ret() { for (auto& v : *s) e->put(v); } } ret{this, &scratch};

    ltk::View dSrc = tmp(W, H);
    be_->upload(dSrc, src);
    ltk::View dOut = tmp(W, H);

    const int N = std::max(0, p.frames);
    if (p.showKey || N < 1 || p.gain <= 0.0f) {
        ltk::CompArgs c = {dSrc, dSrc, dOut, 0, p.showKey ? 1 : 0, p.blend, p.thresh, std::max(0.001f, p.soft), p.gain, p.warm};
        be_->run(K_COMP, &c, W, H);
        be_->download(dOut, out);
        return;
    }

    const bool gap = p.gap;
    const int S = gap ? std::max(1, p.samples) : 1;
    const float range = p.range * ps, driftX = p.driftX * ps, driftY = p.driftY * ps;
    const float amp = p.amp * ps, thick = p.thick * ps, spread = p.spread * ps;
    const float smokeSc = std::max(1.0f, p.smokeScale * ps);
    const int fdiv = std::max(1, (int)std::floor(W / 960.0 + 0.5));
    const int fw = std::max(1, W / fdiv), fh = std::max(1, H / fdiv);
    const float fsig = std::max(0.5f, range / fdiv);
    const float lowGain = 6.2831853f * fsig * fsig;
    const float ph = p.phase + p.speed * (float)time;
    const bool useSmoke = p.smoke > 0.0f;

    uint64_t sig = 0;
    {
        float s[5] = {p.thresh, p.soft, range, (float)p.iters, (float)fdiv};
        for (float f : s) { uint32_t u; std::memcpy(&u, &f, 4); sig = mix(sig, u); }
    }

    auto blur = [&](const ltk::View& img, float sigma) {
        if (sigma < 0.3f) return;
        int radius = std::max(1, (int)std::ceil(sigma * 2.5f));
        ltk::View t = get(img.w, img.h);       // launches are stream-ordered, so recycling right away is safe
        ltk::BlurArgs a = {img, t, 1, 0, radius, sigma};
        be_->run(K_BLUR, &a, img.w, img.h);
        ltk::BlurArgs b = {t, img, 0, 1, radius, sigma};
        be_->run(K_BLUR, &b, img.w, img.h);
        put(t);
    };
    auto keyOf = [&](const ltk::View& in, const ltk::View& hk) {
        ltk::KeyArgs a = {in, hk, p.thresh, std::max(0.001f, p.soft)};
        be_->run(K_KEY, &a, W, H);
    };
    auto lowKey = [&](const ltk::View& hk, const ltk::View& lo) {
        ltk::DownArgs a = {hk, lo, fdiv, lowGain};
        be_->run(K_DOWN, &a, fw, fh);
        blur(lo, fsig);
    };
    auto flow = [&](const ltk::View& bo, const ltk::View& bn) {
        ltk::View fl = get(fw, fh), nf = get(fw, fh), p1 = get(fw, fh), p2 = get(fw, fh);
        bool have = false;
        for (int it = 0; it < std::max(1, p.iters); ++it) {
            ltk::GradArgs g0 = {bo, bn, have ? fl : bo, p1, 0, have ? 1 : 0};
            be_->run(K_GRAD, &g0, fw, fh);
            ltk::GradArgs g1 = {bo, bn, have ? fl : bo, p2, 1, have ? 1 : 0};
            be_->run(K_GRAD, &g1, fw, fh);
            blur(p1, fsig); blur(p2, fsig);
            ltk::SolveArgs s = {p1, p2, have ? fl : p1, nf, have ? 1 : 0, 2.5f * fsig};
            be_->run(K_SOLVE, &s, fw, fh);
            std::swap(fl, nf);
            have = true;
        }
        ltk::View pr = get(fw, fh);           // owned by the cache, not scratch
        ltk::PrepArgs pa = {fl, bo, bn, pr};
        be_->run(K_PREP, &pa, fw, fh);
        blur(pr, fsig);
        put(fl); put(nf); put(p1); put(p2);
        return pr;
    };
    auto smoke = [&](const ltk::View& g, float age) {
        ltk::SmokeArgs a = {g, smokeSc, ph, age};
        be_->run(K_SMOKE, &a, g.w, g.h);
    };

    ltk::View dFrame = tmp(W, H), dHk = tmp(W, H), dAcc = tmp(W, H);
    ltk::View dLo = tmp(fw, fh), dNewLo = tmp(fw, fh);
    const int gw = W / ltk::SMOKE_CELL + 2, gh = H / ltk::SMOKE_CELL + 2;
    ltk::View gPrev = tmp(gw, gh), gNext = tmp(gw, gh);

    uint64_t fpNew = fingerprint(src), fpOld = fpNew;
    if (gap) { keyOf(dSrc, dHk); lowKey(dHk, dNewLo); }
    if (useSmoke) smoke(gPrev, 0.0f);

    ltk::View frame = dSrc;
    Img host;
    for (int k = 1; k <= N; ++k) {
        if (fetch(k, host) && host.w == W && host.h == H) {
            be_->upload(dFrame, host);
            frame = dFrame;
            fpOld = fingerprint(host);
        }                                      // else: reuse the last frame we had
        keyOf(frame, dHk);

        ltk::View fs = dHk;
        if (gap) {
            lowKey(dHk, dLo);
            uint64_t key = mix(mix(sig, fpOld), fpNew * 31ull + 7);
            auto it = flow_.find(key);
            if (it != flow_.end()) {
                fs = it->second;
                lru_.remove(key); lru_.push_front(key);
            } else {
                fs = flow(dLo, dNewLo);
                cachePut(key, fs, size_t(2 * N + 8));
            }
        }
        if (useSmoke) smoke(gNext, (float)k);

        ltk::SmearArgs a;
        a.acc = dAcc; a.hk = dHk; a.fs = fs; a.g0 = gPrev; a.g1 = gNext;
        a.first = (k == 1); a.gap = gap; a.useFs = gap; a.useSmoke = useSmoke;
        a.echo = k; a.frames = N; a.samples = S;
        a.weight = std::pow(p.decay, (float)(k - 1)); a.flowScale = (float)fdiv;
        a.amp = amp; a.freq = p.freq; a.ph = ph; a.thick = thick; a.spread = spread;
        a.driftX = driftX; a.driftY = driftY; a.smoke = p.smoke; a.smokeScale = smokeSc; a.edge = p.edge;
        be_->run(K_SMEAR, &a, W, H);

        if (gap) { std::swap(dLo, dNewLo); fpNew = fpOld; }
        if (useSmoke) std::swap(gPrev, gNext);
    }

    ltk::CompArgs c = {dSrc, dAcc, dOut, 1, 0, p.blend, p.thresh, std::max(0.001f, p.soft), p.gain, p.warm};
    be_->run(K_COMP, &c, W, H);
    be_->download(dOut, out);
}

} // namespace lt
