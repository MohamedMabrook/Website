// LightTrailsCore.h
// Light trail engine. One render pipeline, two backends: CPU threads, or CUDA through the
// NVIDIA driver API (loaded at runtime, so no CUDA install is needed on the user's machine).
#pragma once
#include <cstdint>
#include <functional>
#include <list>
#include <map>
#include <memory>
#include <mutex>
#include <string>
#include <vector>

#include "LightTrailsKernels.h"

namespace lt {

struct Img {
    int w = 0, h = 0;
    std::vector<float> d;   // RGBA float, row 0 = bottom
    Img() {}
    Img(int W, int H) : w(W), h(H), d(size_t(W) * H * 4, 0.0f) {}
    void resize(int W, int H) { w = W; h = H; d.assign(size_t(W) * H * 4, 0.0f); }
    float* px(int x, int y) { return &d[(size_t(y) * w + x) * 4]; }
    const float* px(int x, int y) const { return &d[(size_t(y) * w + x) * 4]; }
};

struct Params {
    float thresh = 0.80f, soft = 0.10f;
    bool  showKey = false;
    int   frames = 12;
    float decay = 0.85f;
    bool  gap = true;
    int   samples = 6;
    float range = 24.0f;
    int   iters = 3;
    float driftX = 0.0f, driftY = 0.0f;
    float edge = 0.0f;
    float amp = 20.0f, freq = 1.5f, phase = 0.0f, speed = 0.15f;
    float smoke = 0.5f, smokeScale = 80.0f;
    float thick = 1.5f, spread = 10.0f;
    float warm = 0.2f, gain = 1.0f;
    int   blend = 0;
};

using FetchFn = std::function<bool(int k, Img& out)>;

enum KernelId { K_KEY, K_DOWN, K_BLUR, K_GRAD, K_SOLVE, K_PREP, K_SMOKE, K_SMEAR, K_COMP, K_COUNT };
extern const char* const kKernelNames[K_COUNT];

// Memory + kernel launch. Throws std::runtime_error on failure.
class Backend {
public:
    virtual ~Backend() {}
    virtual const std::string& name() const = 0;
    virtual ltk::View alloc(int w, int h) = 0;
    virtual void release(const ltk::View& v) = 0;
    virtual void upload(const ltk::View& v, const Img& src) = 0;
    virtual void download(const ltk::View& v, Img& dst) = 0;
    virtual void run(KernelId k, const void* args, int w, int h) = 0;
    virtual void begin() {}   // called around every render (CUDA: push/pop context)
    virtual void end() {}
};

std::unique_ptr<Backend> makeCpuBackend();
// Returns null (and fills err) if CUDA is unavailable.
std::unique_ptr<Backend> makeCudaBackend(std::string& err);

class Engine {
public:
    explicit Engine(std::unique_ptr<Backend> b) : be_(std::move(b)) {}
    ~Engine();
    const std::string& backendName() const { return be_->name(); }
    void render(const Img& src, double time, float pixelScale, const Params& p, const FetchFn& fetch, Img& out);

private:
    std::unique_ptr<Backend> be_;
    // buffer pool, keyed by size
    std::multimap<std::pair<int, int>, ltk::View> pool_;
    ltk::View get(int w, int h);
    void put(const ltk::View& v);
    void clearPool();
    // flow cache: key -> buffer (owned by cache)
    std::list<uint64_t> lru_;
    std::map<uint64_t, ltk::View> flow_;
    void cachePut(uint64_t key, const ltk::View& v, size_t cap);
    int poolW_ = 0, poolH_ = 0;
};

void parallelRows(int h, const std::function<void(int y0, int y1)>& fn);
void logLine(const std::string& s);   // appends to %TEMP%/LightTrails.log

} // namespace lt
