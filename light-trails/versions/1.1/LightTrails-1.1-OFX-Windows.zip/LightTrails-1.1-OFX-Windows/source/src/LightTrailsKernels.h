// LightTrailsKernels.h
// Per-pixel kernels shared by the CPU engine and the CUDA engine. The same source compiles
// as plain C++ (CPU) and as CUDA device code (clang -x cuda, no CUDA SDK headers needed).
// Images are float RGBA, row 0 = bottom, tightly packed. Pixel centres sit at +0.5.
#pragma once

#if defined(__CUDA__) && defined(__CUDA_ARCH__)
#  define LT_GPU 1
#  define LT_DEV __attribute__((device)) static inline
#  define LT_EXP(x) __nvvm_ex2_approx_f((x) * 1.44269504f)
#else
#  define LT_GPU 0
#  if defined(__CUDA__)
#    define LT_DEV __attribute__((host)) __attribute__((device)) static inline
#  else
#    define LT_DEV static inline
#  endif
#  include <cmath>
#  define LT_EXP(x) expf(x)
#endif
#define LT_FLOOR(x) __builtin_floorf(x)
#define LT_SQRT(x)  __builtin_sqrtf(x)
#define LT_FABS(x)  __builtin_fabsf(x)

namespace ltk {

struct View { float* d; int w; int h; };   // 16 bytes, same layout on host and device

struct F4 { float x, y, z, w; };

// ---- argument blocks (passed by value to every kernel) ---------------------------------
struct KeyArgs   { View src, dst; float thresh, soft; };
struct DownArgs  { View src, dst; int fdiv; float gain; };
struct BlurArgs  { View src, dst; int dx, dy, radius; float sigma; };
struct GradArgs  { View bo, bn, fl, dst; int mode, useFlow; };
struct SolveArgs { View p1, p2, fl, dst; int useFlow; float lim; };
struct PrepArgs  { View fl, bo, bn, dst; };
struct SmokeArgs { View dst; float scale, ph, age; };
struct SmearArgs {
    View acc, hk, fs, g0, g1;
    int first, gap, useFs, useSmoke, echo, frames, samples;
    float weight, flowScale, amp, freq, ph, thick, spread, driftX, driftY, smoke, smokeScale, edge;
};
struct CompArgs  { View src, acc, dst; int useAcc, showKey, blend; float thresh, soft, gain, warm; };

static const int SMOKE_CELL = 4;

// ---- helpers ---------------------------------------------------------------------------
LT_DEV float* vpx(const View& v, int x, int y) { return v.d + ((long long)y * v.w + x) * 4; }

LT_DEV float ltSat(float x) { return x < 0.0f ? 0.0f : (x > 1.0f ? 1.0f : x); }

LT_DEV float ltKey(float r, float g, float b, float t, float k)
{
    float y = 0.2126f * r + 0.7152f * g + 0.0722f * b;
    float x = ltSat((y - t) / k);
    return x * x * (3.0f - 2.0f * x);
}

LT_DEV float ltHash(int x, int y, int s)
{
    unsigned int h = ((unsigned int)x * 73856093u) ^ ((unsigned int)y * 19349663u) ^ ((unsigned int)s * 83492791u);
    h ^= h >> 13;
    h *= 0x5bd1e995u;
    h ^= h >> 15;
    return (float)(h & 0xFFFFu) / 65535.0f;
}

// Fast sine: range-reduce to [-pi/2, pi/2], 9th-order Taylor (max error ~1.5e-5).
LT_DEV float fsin(float x)
{
    const float INV_TAU = 0.15915494f, TAU = 6.2831853f, PI = 3.14159265f, HPI = 1.57079633f;
    x -= TAU * LT_FLOOR(x * INV_TAU + 0.5f);
    if (x > HPI) x = PI - x; else if (x < -HPI) x = -PI - x;
    float x2 = x * x;
    return x * (1.0f + x2 * (-1.6666667e-1f + x2 * (8.3333333e-3f + x2 * (-1.9841270e-4f + x2 * 2.7557319e-6f))));
}

// Integer-hash lattice: identical on CPU and GPU (a sin-based hash is not).
LT_DEV float ltLattice(float x, float y)
{
    unsigned int h = ((unsigned int)(int)x * 0x8da6b343u) ^ ((unsigned int)(int)y * 0xd8163841u);
    h ^= h >> 15; h *= 0x2c1b3c6du; h ^= h >> 12; h *= 0x297a2d39u; h ^= h >> 15;
    return (float)(h & 0xFFFFFFu) * (2.0f / 16777215.0f) - 1.0f;
}

LT_DEV float ltNoise(float x, float y)
{
    float ix = LT_FLOOR(x), iy = LT_FLOOR(y);
    float fx = x - ix, fy = y - iy;
    float ux = fx * fx * (3.0f - 2.0f * fx);
    float uy = fy * fy * (3.0f - 2.0f * fy);
    float a = ltLattice(ix, iy),        b = ltLattice(ix + 1.0f, iy);
    float c = ltLattice(ix, iy + 1.0f), d = ltLattice(ix + 1.0f, iy + 1.0f);
    float ab = a + (b - a) * ux, cd = c + (d - c) * ux;
    return ab + (cd - ab) * uy;
}

LT_DEV F4 texel(const View& t, int x, int y)
{
    F4 r = {0.0f, 0.0f, 0.0f, 0.0f};
    if (x < 0 || y < 0 || x >= t.w || y >= t.h) return r;
    const float* p = vpx(t, x, y);
    r.x = p[0]; r.y = p[1]; r.z = p[2]; r.w = p[3];
    return r;
}

// Bilinear sample, border = 0
LT_DEV F4 ltS(const View& t, float px, float py)
{
    float fx = px - 0.5f, fy = py - 0.5f;
    float flx = LT_FLOOR(fx), fly = LT_FLOOR(fy);
    int x0 = (int)flx, y0 = (int)fly;
    float ax = fx - flx, ay = fy - fly;
    float w00 = (1 - ax) * (1 - ay), w10 = ax * (1 - ay), w01 = (1 - ax) * ay, w11 = ax * ay;
    F4 r;
    if (x0 >= 0 && y0 >= 0 && x0 + 1 < t.w && y0 + 1 < t.h) {
        const float* p0 = vpx(t, x0, y0);
        const float* p1 = p0 + (long long)t.w * 4;
        r.x = p0[0] * w00 + p0[4] * w10 + p1[0] * w01 + p1[4] * w11;
        r.y = p0[1] * w00 + p0[5] * w10 + p1[1] * w01 + p1[5] * w11;
        r.z = p0[2] * w00 + p0[6] * w10 + p1[2] * w01 + p1[6] * w11;
        r.w = p0[3] * w00 + p0[7] * w10 + p1[3] * w01 + p1[7] * w11;
        return r;
    }
    F4 a = texel(t, x0, y0), b = texel(t, x0 + 1, y0), c = texel(t, x0, y0 + 1), d = texel(t, x0 + 1, y0 + 1);
    r.x = a.x * w00 + b.x * w10 + c.x * w01 + d.x * w11;
    r.y = a.y * w00 + b.y * w10 + c.y * w01 + d.y * w11;
    r.z = a.z * w00 + b.z * w10 + c.z * w01 + d.z * w11;
    r.w = a.w * w00 + b.w * w10 + c.w * w01 + d.w * w11;
    return r;
}

LT_DEV float ltSx(const View& t, float px, float py) { return ltS(t, px, py).x; }

LT_DEV void put(const View& o, int x, int y, float a, float b, float c, float d)
{
    float* p = vpx(o, x, y); p[0] = a; p[1] = b; p[2] = c; p[3] = d;
}

// ---- kernels (one call = one output pixel) ---------------------------------------------
LT_DEV void kKey(int x, int y, const KeyArgs& a)
{
    const float* c = vpx(a.src, x, y);
    float k = ltKey(c[0], c[1], c[2], a.thresh, a.soft);
    put(a.dst, x, y, c[0] * k, c[1] * k, c[2] * k, k);
}

LT_DEV void kDown(int x, int y, const DownArgs& a)
{
    float sum = 0.0f;
    for (int j = 0; j < a.fdiv; ++j)
        for (int i = 0; i < a.fdiv; ++i)
            sum += texel(a.src, x * a.fdiv + i, y * a.fdiv + j).w;
    sum *= a.gain / (float)(a.fdiv * a.fdiv);
    put(a.dst, x, y, sum, sum, sum, 1.0f);
}

LT_DEV void kBlur(int x, int y, const BlurArgs& a)
{
    float inv = 1.0f / (2.0f * a.sigma * a.sigma);
    float s0 = 0, s1 = 0, s2 = 0, s3 = 0, ws = 0;
    for (int i = -a.radius; i <= a.radius; ++i) {
        float w = LT_EXP(-(float)(i * i) * inv);
        F4 c = texel(a.src, x + i * a.dx, y + i * a.dy);
        s0 += c.x * w; s1 += c.y * w; s2 += c.z * w; s3 += c.w * w; ws += w;
    }
    float n = 1.0f / ws;
    put(a.dst, x, y, s0 * n, s1 * n, s2 * n, s3 * n);
}

LT_DEV void kGrad(int x, int y, const GradArgs& a)
{
    float px = x + 0.5f, py = y + 0.5f;
    float fx = 0.0f, fy = 0.0f;
    if (a.useFlow) { const float* f = vpx(a.fl, x, y); fx = f[0]; fy = f[1]; }
    float qx = px + fx, qy = py + fy;
    float o0  = ltSx(a.bo, px, py);
    float ixo = 0.5f * (ltSx(a.bo, px + 1.0f, py) - ltSx(a.bo, px - 1.0f, py));
    float iyo = 0.5f * (ltSx(a.bo, px, py + 1.0f) - ltSx(a.bo, px, py - 1.0f));
    float n0  = ltSx(a.bn, qx, qy);
    float ixn = 0.5f * (ltSx(a.bn, qx + 1.0f, qy) - ltSx(a.bn, qx - 1.0f, qy));
    float iyn = 0.5f * (ltSx(a.bn, qx, qy + 1.0f) - ltSx(a.bn, qx, qy - 1.0f));
    float Ix = 0.5f * (ixo + ixn), Iy = 0.5f * (iyo + iyn), It = n0 - o0;
    if (a.mode == 0) put(a.dst, x, y, Ix * Ix, Ix * Iy, Iy * Iy, 1.0f);
    else             put(a.dst, x, y, Ix * It, Iy * It, 0.0f, 1.0f);
}

LT_DEV void kSolve(int x, int y, const SolveArgs& a)
{
    const float* A = vpx(a.p1, x, y);
    const float* B = vpx(a.p2, x, y);
    float pa = A[0], pb = A[1], pc = A[2];
    float tr = pa + pc;
    float det = pa * pc - pb * pb + 1.0e-4f * tr * tr + 1.0e-20f;
    float fx = -(pc * B[0] - pb * B[1]) / det;
    float fy = -(pa * B[1] - pb * B[0]) / det;
    if (a.useFlow) { const float* f = vpx(a.fl, x, y); fx += f[0]; fy += f[1]; }
    float m = LT_SQRT(fx * fx + fy * fy);
    if (m > a.lim) { float s = a.lim / m; fx *= s; fy *= s; }
    put(a.dst, x, y, fx, fy, 0.0f, 1.0f);
}

LT_DEV void kPrep(int x, int y, const PrepArgs& a)
{
    const float* f = vpx(a.fl, x, y);
    float c = vpx(a.bo, x, y)[0] + vpx(a.bn, x, y)[0];
    put(a.dst, x, y, f[0] * c, f[1] * c, c, 1.0f);
}

// Smoke displacement field at one age; node (i, j) sits at pixel (i * CELL, j * CELL).
LT_DEV void kSmoke(int i, int j, const SmokeArgs& a)
{
    float zx = (float)(i * SMOKE_CELL) / a.scale, zy = (float)(j * SMOKE_CELL) / a.scale;
    put(a.dst, i, j,
        ltNoise(zx + 0.37f * a.ph, zy - 0.21f * a.age),
        ltNoise(zx - 0.29f * a.ph + 17.3f, zy + 0.23f * a.age + 5.1f), 0.0f, 0.0f);
}

LT_DEV void smokeAt(const View& g, float px, float py, float& sx, float& sy)
{
    float fx = px / SMOKE_CELL, fy = py / SMOKE_CELL;
    int i = (int)fx, j = (int)fy;
    if (i > g.w - 2) i = g.w - 2;
    if (j > g.h - 2) j = g.h - 2;
    if (i < 0) i = 0;
    if (j < 0) j = 0;
    float ax = fx - i, ay = fy - j;
    const float* a = vpx(g, i, j);
    const float* b = a + 4;
    const float* c = a + (long long)g.w * 4;
    const float* d = c + 4;
    float w00 = (1 - ax) * (1 - ay), w10 = ax * (1 - ay), w01 = (1 - ax) * ay, w11 = ax * ay;
    sx = a[0] * w00 + b[0] * w10 + c[0] * w01 + d[0] * w11;
    sy = a[1] * w00 + b[1] * w10 + c[1] * w01 + d[1] * w11;
}

LT_DEV void kSmear(int x, int y, const SmearArgs& P)
{
    const float TAU = 6.2831853f;
    const float w = (float)P.hk.w, h = (float)P.hk.h;
    float px = x + 0.5f, py = y + 0.5f;
    float vx = 0.0f, vy = 0.0f;
    if (P.gap && P.useFs) {
        F4 f = ltS(P.fs, px * P.fs.w / w, py * P.fs.h / h);
        float inv = P.flowScale / (f.z + 1.0e-6f);
        vx = f.x * inv; vy = f.y * inv;
    }
    float dx = vx + P.driftX, dy = vy + P.driftY;
    float m = LT_SQRT(dx * dx + dy * dy);
    float tx = 1.0f, ty = 0.0f;
    if (m > 0.05f) { tx = dx / m; ty = dy / m; }
    float nx = -ty, ny = tx;

    int k = P.echo, S = P.samples;
    float N = (float)P.frames, ph = P.ph;
    float r = 0.0f, g = 0.0f, b = 0.0f;
    float s0x = 0, s0y = 0, s1x = 0, s1y = 0;
    if (P.useSmoke) { smokeAt(P.g0, px, py, s0x, s0y); smokeAt(P.g1, px, py, s1x, s1y); }
    for (int i = 0; i < S; i++) {
        float j = ltHash(x, y, k * 31 + i);
        float s = P.gap ? ((float)i + j) / (float)S : 0.0f;
        float age = (float)(k - 1) + s;
        float a = age / N;
        float wv = fsin(TAU * P.freq * a - ph) + 0.45f * fsin(TAU * P.freq * 2.3f * a + 1.7f * ph + 1.3f);
        float jit = (P.thick + P.spread * a) * (2.0f * ltHash(x, y, k * 977 + i * 13) - 1.0f);
        float off = P.amp * a * wv + jit;
        float sx = 0.0f, sy = 0.0f;
        if (P.useSmoke) {
            float sa = P.smoke * P.amp * a;
            sx = sa * (s0x + (s1x - s0x) * s);
            sy = sa * (s0y + (s1y - s0y) * s);
        }
        float qx = px - s * vx - P.driftX * age - nx * off - sx;
        float qy = py - s * vy - P.driftY * age - ny * off - sy;
        if (qx < 0.0f || qy < 0.0f || qx >= w || qy >= h) continue;
        float e = LT_FABS(qx / w - 0.5f) * 2.0f;
        float wE = 1.0f - P.edge * (1.0f - e * e);
        F4 c = ltS(P.hk, qx, qy);
        r += c.x * wE; g += c.y * wE; b += c.z * wE;
    }
    float n = P.weight / (float)S;
    float* o = vpx(P.acc, x, y);
    if (P.first) { o[0] = r * n; o[1] = g * n; o[2] = b * n; o[3] = 1.0f; }
    else         { o[0] += r * n; o[1] += g * n; o[2] += b * n; }
}

LT_DEV void kComp(int x, int y, const CompArgs& a)
{
    const float* s = vpx(a.src, x, y);
    if (a.showKey) {
        float k = ltKey(s[0], s[1], s[2], a.thresh, a.soft);
        put(a.dst, x, y, k, k, k, 1.0f);
        return;
    }
    float tr = 0, tg = 0, tb = 0;
    if (a.useAcc) {
        const float* t = vpx(a.acc, x, y);
        tr = t[0] * a.gain * (1.0f + 0.5f * a.warm);
        tg = t[1] * a.gain;
        tb = t[2] * a.gain * (1.0f - 0.5f * a.warm);
    }
    if (a.blend == 2)      put(a.dst, x, y, tr, tg, tb, 1.0f);
    else if (a.blend == 1) put(a.dst, x, y, 1.0f - (1.0f - s[0]) * (1.0f - ltSat(tr)),
                                           1.0f - (1.0f - s[1]) * (1.0f - ltSat(tg)),
                                           1.0f - (1.0f - s[2]) * (1.0f - ltSat(tb)), s[3]);
    else                   put(a.dst, x, y, s[0] + tr, s[1] + tg, s[2] + tb, s[3]);
}

} // namespace ltk
