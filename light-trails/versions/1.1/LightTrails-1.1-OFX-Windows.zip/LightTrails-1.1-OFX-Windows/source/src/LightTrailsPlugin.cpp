// LightTrailsPlugin.cpp
// OpenFX wrapper (Color page / Edit page / Fusion in DaVinci Resolve) around LightTrailsCore.
// Temporal plugin: requests the previous N frames of the source clip for every render.

#include <algorithm>
#include <cmath>
#include <cstring>
#include <memory>
#include <string>

#include "ofxsImageEffect.h"
#include "ofxsMultiThread.h"

#include "LightTrailsCore.h"

#define kPluginName        "Light Trails"
#define kPluginGrouping    "Light Trails"
#define kPluginDescription "Wavy, smoky trails on the brightest highlights. Each trail follows its light's real motion across the previous frames."
#define kPluginIdentifier  "com.lighttrails.ofx.LightTrails"
#define kPluginVersionMajor 1
#define kPluginVersionMinor 1

static const int kMaxFrames = 48;

// ---------------------------------------------------------------------------------------
// Pixel conversion
// ---------------------------------------------------------------------------------------
template <typename T> static inline float toF(T v);
template <> inline float toF<unsigned char>(unsigned char v) { return v / 255.0f; }
template <> inline float toF<unsigned short>(unsigned short v) { return v / 65535.0f; }
template <> inline float toF<float>(float v) { return v; }

template <typename T> static inline T fromF(float v);
template <> inline unsigned char fromF<unsigned char>(float v) { v = std::min(std::max(v, 0.0f), 1.0f); return (unsigned char)(v * 255.0f + 0.5f); }
template <> inline unsigned short fromF<unsigned short>(float v) { v = std::min(std::max(v, 0.0f), 1.0f); return (unsigned short)(v * 65535.0f + 0.5f); }
template <> inline float fromF<float>(float v) { return v; }

template <typename T>
static void readImage(const OFX::Image& im, const OfxRectI& area, int nComp, lt::Img& out)
{
    const int W = area.x2 - area.x1, H = area.y2 - area.y1;
    out.resize(W, H);
    lt::parallelRows(H, [&](int y0, int y1) {
        for (int y = y0; y < y1; ++y)
            for (int x = 0; x < W; ++x) {
                const T* p = static_cast<const T*>(im.getPixelAddress(area.x1 + x, area.y1 + y));
                float* o = out.px(x, y);
                if (!p) { o[0] = o[1] = o[2] = o[3] = 0.0f; continue; }
                if (nComp == 1) { o[0] = o[1] = o[2] = 0.0f; o[3] = toF<T>(p[0]); continue; }
                o[0] = toF<T>(p[0]); o[1] = toF<T>(p[1]); o[2] = toF<T>(p[2]);
                o[3] = nComp == 4 ? toF<T>(p[3]) : 1.0f;
            }
    });
}

static bool readAny(const OFX::Image& im, const OfxRectI& area, lt::Img& out)
{
    int nComp = 4;
    switch (im.getPixelComponents()) {
        case OFX::ePixelComponentRGBA:  nComp = 4; break;
        case OFX::ePixelComponentRGB:   nComp = 3; break;
        case OFX::ePixelComponentAlpha: nComp = 1; break;
        default: return false;
    }
    switch (im.getPixelDepth()) {
        case OFX::eBitDepthUByte:  readImage<unsigned char>(im, area, nComp, out); return true;
        case OFX::eBitDepthUShort: readImage<unsigned short>(im, area, nComp, out); return true;
        case OFX::eBitDepthFloat:  readImage<float>(im, area, nComp, out); return true;
        default: return false;
    }
}

template <typename T>
static void writeImage(OFX::Image& im, const OfxRectI& win, const OfxRectI& area, int nComp, const lt::Img& src)
{
    const int H = win.y2 - win.y1;
    lt::parallelRows(H, [&](int y0, int y1) {
        for (int yy = y0; yy < y1; ++yy) {
            int y = win.y1 + yy;
            for (int x = win.x1; x < win.x2; ++x) {
                T* p = static_cast<T*>(im.getPixelAddress(x, y));
                if (!p) continue;
                int sx = x - area.x1, sy = y - area.y1;
                float c[4] = {0, 0, 0, 0};
                if (sx >= 0 && sy >= 0 && sx < src.w && sy < src.h) {
                    const float* s = src.px(sx, sy);
                    c[0] = s[0]; c[1] = s[1]; c[2] = s[2]; c[3] = s[3];
                }
                if (nComp == 1) { p[0] = fromF<T>(c[3]); continue; }
                p[0] = fromF<T>(c[0]); p[1] = fromF<T>(c[1]); p[2] = fromF<T>(c[2]);
                if (nComp == 4) p[3] = fromF<T>(c[3]);
            }
        }
    });
}

static bool writeAny(OFX::Image& im, const OfxRectI& win, const OfxRectI& area, const lt::Img& src)
{
    int nComp = 4;
    switch (im.getPixelComponents()) {
        case OFX::ePixelComponentRGBA:  nComp = 4; break;
        case OFX::ePixelComponentRGB:   nComp = 3; break;
        case OFX::ePixelComponentAlpha: nComp = 1; break;
        default: return false;
    }
    switch (im.getPixelDepth()) {
        case OFX::eBitDepthUByte:  writeImage<unsigned char>(im, win, area, nComp, src); return true;
        case OFX::eBitDepthUShort: writeImage<unsigned short>(im, win, area, nComp, src); return true;
        case OFX::eBitDepthFloat:  writeImage<float>(im, win, area, nComp, src); return true;
        default: return false;
    }
}

// ---------------------------------------------------------------------------------------
// Plugin instance
// ---------------------------------------------------------------------------------------
class LightTrailsPlugin : public OFX::ImageEffect {
public:
    explicit LightTrailsPlugin(OfxImageEffectHandle handle)
        : ImageEffect(handle)
    {
        dstClip_ = fetchClip(kOfxImageEffectOutputClipName);
        srcClip_ = fetchClip(kOfxImageEffectSimpleSourceClipName);

        thresh_  = fetchDoubleParam("threshold");
        soft_    = fetchDoubleParam("softness");
        showKey_ = fetchBooleanParam("showKey");
        frames_  = fetchIntParam("frames");
        decay_   = fetchDoubleParam("decay");
        gap_     = fetchBooleanParam("fillGaps");
        samples_ = fetchIntParam("gapQuality");
        range_   = fetchDoubleParam("motionRange");
        iters_   = fetchIntParam("motionIterations");
        driftX_  = fetchDoubleParam("driftX");
        driftY_  = fetchDoubleParam("driftY");
        edge_    = fetchDoubleParam("edgeBias");
        amp_     = fetchDoubleParam("waveAmplitude");
        freq_    = fetchDoubleParam("waveFrequency");
        phase_   = fetchDoubleParam("phase");
        speed_   = fetchDoubleParam("speed");
        smoke_   = fetchDoubleParam("smoke");
        smokeSc_ = fetchDoubleParam("smokeScale");
        thick_   = fetchDoubleParam("thickness");
        spread_  = fetchDoubleParam("spread");
        warm_    = fetchDoubleParam("warmth");
        gain_    = fetchDoubleParam("intensity");
        blend_   = fetchChoiceParam("blend");
        useGpu_  = fetchBooleanParam("useGpu");
        status_  = fetchStringParam("status");
        setupEngines();
    }

    ~LightTrailsPlugin() override {}

    // CUDA when available and enabled, CPU otherwise. Called on create and when Use GPU changes.
    void setupEngines()
    {
        if (!cpu_) cpu_.reset(new lt::Engine(lt::makeCpuBackend()));
        std::string msg;
        if (useGpu_->getValue() && !gpu_ && !gpuBroken_) {
            std::string err;
            std::unique_ptr<lt::Backend> b = lt::makeCudaBackend(err);
            if (b) {
                gpu_.reset(new lt::Engine(std::move(b)));
                lt::logLine("GPU ready: " + gpu_->backendName());
            } else {
                gpuBroken_ = true;
                gpuError_ = err;
                lt::logLine("GPU unavailable, using CPU: " + err);
            }
        }
        if (!useGpu_->getValue()) msg = "CPU (GPU off)";
        else if (gpu_) msg = gpu_->backendName();
        else msg = "CPU (GPU failed: " + gpuError_ + ")";
        status_->setValue(msg);
    }

    void changedParam(const OFX::InstanceChangedArgs& /*args*/, const std::string& name) override
    {
        if (name == "useGpu") setupEngines();
    }

    lt::Params paramsAt(double t) const
    {
        lt::Params p;
        p.thresh     = (float)thresh_->getValueAtTime(t);
        p.soft       = std::max(0.001f, (float)soft_->getValueAtTime(t));
        p.showKey    = showKey_->getValueAtTime(t);
        p.frames     = std::min(kMaxFrames, std::max(1, frames_->getValueAtTime(t)));
        p.decay      = (float)decay_->getValueAtTime(t);
        p.gap        = gap_->getValueAtTime(t);
        p.samples    = std::max(1, samples_->getValueAtTime(t));
        p.range      = std::max(1.0f, (float)range_->getValueAtTime(t));
        p.iters      = std::max(1, iters_->getValueAtTime(t));
        p.driftX     = (float)driftX_->getValueAtTime(t);
        p.driftY     = (float)driftY_->getValueAtTime(t);
        p.edge       = (float)edge_->getValueAtTime(t);
        p.amp        = (float)amp_->getValueAtTime(t);
        p.freq       = (float)freq_->getValueAtTime(t);
        p.phase      = (float)phase_->getValueAtTime(t);
        p.speed      = (float)speed_->getValueAtTime(t);
        p.smoke      = (float)smoke_->getValueAtTime(t);
        p.smokeScale = (float)smokeSc_->getValueAtTime(t);
        p.thick      = (float)thick_->getValueAtTime(t);
        p.spread     = (float)spread_->getValueAtTime(t);
        p.warm       = (float)warm_->getValueAtTime(t);
        p.gain       = (float)gain_->getValueAtTime(t);
        int b = 0; blend_->getValueAtTime(t, b); p.blend = b;
        return p;
    }

    void getFramesNeeded(const OFX::FramesNeededArguments& args, OFX::FramesNeededSetter& frames) override
    {
        int n = std::min(kMaxFrames, std::max(1, frames_->getValueAtTime(args.time)));
        OfxRangeD r;
        r.min = args.time - n;
        r.max = args.time;
        frames.setFramesNeeded(*srcClip_, r);
    }

    // Trails reach across the frame, so ask for the whole source every time.
    void getRegionsOfInterest(const OFX::RegionsOfInterestArguments& args, OFX::RegionOfInterestSetter& rois) override
    {
        rois.setRegionOfInterest(*srcClip_, srcClip_->getRegionOfDefinition(args.time));
    }

    bool isIdentity(const OFX::IsIdentityArguments& args, OFX::Clip*& identityClip, double& identityTime) override
    {
        if (!showKey_->getValueAtTime(args.time) && gain_->getValueAtTime(args.time) <= 0.0) {
            identityClip = srcClip_;
            identityTime = args.time;
            return true;
        }
        return false;
    }

    void render(const OFX::RenderArguments& args) override
    {
        std::unique_ptr<OFX::Image> dst(dstClip_->fetchImage(args.time));
        std::unique_ptr<const OFX::Image> src(srcClip_->fetchImage(args.time));
        if (!dst.get() || !src.get()) OFX::throwSuiteStatusException(kOfxStatFailed);

        const OfxRectI area = src->getBounds();
        lt::Img cur;
        if (!readAny(*src, area, cur)) OFX::throwSuiteStatusException(kOfxStatErrImageFormat);

        const lt::Params p = paramsAt(args.time);
        const OfxRangeD range = srcClip_->getFrameRange();

        // Previous frames, converted into the current frame's pixel area.
        lt::FetchFn fetch = [&](int k, lt::Img& out) -> bool {
            double t = args.time - k;
            if (t < range.min) return false;
            std::unique_ptr<const OFX::Image> im(srcClip_->fetchImage(t));
            if (!im.get()) return false;
            return readAny(*im, area, out);
        };

        lt::Img res;
        bool done = false;
        if (gpu_ && useGpu_->getValueAtTime(args.time)) {
            try {
                gpu_->render(cur, args.time, (float)args.renderScale.x, p, fetch, res);
                done = true;
            } catch (const std::exception& e) {
                // A CUDA failure mid-render: log it, stop using the GPU, finish this frame on the CPU.
                lt::logLine(std::string("GPU render failed, switching to CPU: ") + e.what());
                gpuError_ = e.what();
                gpuBroken_ = true;
                gpu_.release();          // context may be unusable; do not touch it again
            }
        }
        if (!done) cpu_->render(cur, args.time, (float)args.renderScale.x, p, fetch, res);

        if (!writeAny(*dst, args.renderWindow, area, res)) OFX::throwSuiteStatusException(kOfxStatErrImageFormat);
    }

private:
    OFX::Clip* dstClip_;
    OFX::Clip* srcClip_;
    OFX::DoubleParam *thresh_, *soft_, *decay_, *range_, *driftX_, *driftY_, *edge_;
    OFX::DoubleParam *amp_, *freq_, *phase_, *speed_, *smoke_, *smokeSc_, *thick_, *spread_, *warm_, *gain_;
    OFX::BooleanParam *showKey_, *gap_;
    OFX::IntParam *frames_, *samples_, *iters_;
    OFX::ChoiceParam* blend_;
    OFX::BooleanParam* useGpu_;
    OFX::StringParam* status_;
    std::unique_ptr<lt::Engine> cpu_, gpu_;
    bool gpuBroken_ = false;
    std::string gpuError_;
};

// ---------------------------------------------------------------------------------------
// Factory / description
// ---------------------------------------------------------------------------------------
using namespace OFX;

class LightTrailsFactory : public OFX::PluginFactoryHelper<LightTrailsFactory> {
public:
    LightTrailsFactory() : OFX::PluginFactoryHelper<LightTrailsFactory>(kPluginIdentifier, kPluginVersionMajor, kPluginVersionMinor) {}
    void describe(OFX::ImageEffectDescriptor& desc) override;
    void describeInContext(OFX::ImageEffectDescriptor& desc, OFX::ContextEnum context) override;
    OFX::ImageEffect* createInstance(OfxImageEffectHandle handle, OFX::ContextEnum context) override;
};

void LightTrailsFactory::describe(ImageEffectDescriptor& desc)
{
    desc.setLabels(kPluginName, kPluginName, kPluginName);
    desc.setPluginGrouping(kPluginGrouping);
    desc.setPluginDescription(kPluginDescription);

    desc.addSupportedContext(eContextFilter);
    desc.addSupportedContext(eContextGeneral);

    desc.addSupportedBitDepth(eBitDepthFloat);
    desc.addSupportedBitDepth(eBitDepthUShort);
    desc.addSupportedBitDepth(eBitDepthUByte);

    desc.setSingleInstance(false);
    desc.setHostFrameThreading(false);      // the engine threads itself
    desc.setSupportsMultiResolution(true);
    desc.setSupportsTiles(false);           // trails need the whole frame
    desc.setTemporalClipAccess(true);       // reads previous frames
    desc.setRenderTwiceAlways(false);
    desc.setSupportsMultipleClipPARs(false);
    desc.setRenderThreadSafety(eRenderInstanceSafe);
}

static DoubleParamDescriptor* dbl(ImageEffectDescriptor& d, const char* name, const char* label, const char* hint,
                                  double def, double lo, double hi, double dlo, double dhi, GroupParamDescriptor* grp)
{
    DoubleParamDescriptor* p = d.defineDoubleParam(name);
    p->setLabels(label, label, label);
    p->setHint(hint);
    p->setDefault(def);
    p->setRange(lo, hi);
    p->setDisplayRange(dlo, dhi);
    p->setIncrement((dhi - dlo) / 200.0);
    p->setDoubleType(eDoubleTypePlain);
    if (grp) p->setParent(*grp);
    return p;
}

static IntParamDescriptor* intp(ImageEffectDescriptor& d, const char* name, const char* label, const char* hint,
                                int def, int lo, int hi, GroupParamDescriptor* grp)
{
    IntParamDescriptor* p = d.defineIntParam(name);
    p->setLabels(label, label, label);
    p->setHint(hint);
    p->setDefault(def);
    p->setRange(lo, hi);
    p->setDisplayRange(lo, hi);
    if (grp) p->setParent(*grp);
    return p;
}

static BooleanParamDescriptor* boolp(ImageEffectDescriptor& d, const char* name, const char* label, const char* hint,
                                     bool def, GroupParamDescriptor* grp)
{
    BooleanParamDescriptor* p = d.defineBooleanParam(name);
    p->setLabels(label, label, label);
    p->setHint(hint);
    p->setDefault(def);
    if (grp) p->setParent(*grp);
    return p;
}

static GroupParamDescriptor* group(ImageEffectDescriptor& d, const char* name, const char* label)
{
    GroupParamDescriptor* g = d.defineGroupParam(name);
    g->setLabels(label, label, label);
    g->setOpen(true);
    return g;
}

void LightTrailsFactory::describeInContext(ImageEffectDescriptor& desc, ContextEnum /*context*/)
{
    ClipDescriptor* src = desc.defineClip(kOfxImageEffectSimpleSourceClipName);
    src->addSupportedComponent(ePixelComponentRGBA);
    src->addSupportedComponent(ePixelComponentRGB);
    src->setTemporalClipAccess(true);
    src->setSupportsTiles(false);
    src->setIsMask(false);

    ClipDescriptor* dst = desc.defineClip(kOfxImageEffectOutputClipName);
    dst->addSupportedComponent(ePixelComponentRGBA);
    dst->addSupportedComponent(ePixelComponentRGB);
    dst->setSupportsTiles(false);

    PageParamDescriptor* page = desc.definePageParam("Controls");

    GroupParamDescriptor* gKey = group(desc, "grpKey", "Highlight Key");
    page->addChild(*dbl(desc, "threshold", "Threshold", "Luma above this starts making trails. Set it with Show Highlight Key on.", 0.80, 0.0, 100.0, 0.0, 4.0, gKey));
    page->addChild(*dbl(desc, "softness", "Softness", "Feathers the key edge.", 0.10, 0.001, 10.0, 0.001, 1.0, gKey));
    page->addChild(*boolp(desc, "showKey", "Show Highlight Key", "Shows the key in black and white.", false, gKey));

    GroupParamDescriptor* gTrail = group(desc, "grpTrail", "Trail");
    page->addChild(*intp(desc, "frames", "Frames", "How many previous frames make up the trail.", 12, 1, kMaxFrames, gTrail));
    page->addChild(*dbl(desc, "decay", "Decay", "Brightness kept per frame of age.", 0.85, 0.0, 1.0, 0.0, 1.0, gTrail));
    page->addChild(*boolp(desc, "fillGaps", "Fill Gaps (motion)", "Tracks each light between frames and draws a continuous line. Off gives a stepped strobe look and renders faster.", true, gTrail));
    page->addChild(*intp(desc, "gapQuality", "Gap Quality", "Samples per frame of trail. Higher is smoother.", 6, 1, 24, gTrail));
    page->addChild(*dbl(desc, "motionRange", "Motion Range px", "Largest per-frame light movement the tracker follows, in full-res pixels.", 24.0, 1.0, 400.0, 4.0, 160.0, gTrail));
    page->addChild(*intp(desc, "motionIterations", "Motion Iterations", "Tracker refinement passes. Raise for very fast lights.", 3, 1, 6, gTrail));
    page->addChild(*dbl(desc, "driftX", "Drift X px/frame", "Pushes the trail sideways per frame of age. Lets static lights trail on a locked-off shot.", 0.0, -200.0, 200.0, -20.0, 20.0, gTrail));
    page->addChild(*dbl(desc, "driftY", "Drift Y px/frame", "Pushes the trail up (+) or down (-) per frame of age, like rising smoke.", 0.0, -200.0, 200.0, -20.0, 20.0, gTrail));
    page->addChild(*dbl(desc, "edgeBias", "Edge Bias", "Favors lights near the left and right frame edges.", 0.0, 0.0, 1.0, 0.0, 1.0, gTrail));

    GroupParamDescriptor* gWave = group(desc, "grpWave", "Wave and Smoke");
    page->addChild(*dbl(desc, "waveAmplitude", "Wave Amplitude px", "Sideways wobble at the tail. Ramps from zero at the light.", 20.0, 0.0, 1000.0, 0.0, 120.0, gWave));
    page->addChild(*dbl(desc, "waveFrequency", "Wave Frequency", "Wave cycles along the trail.", 1.5, 0.0, 50.0, 0.0, 8.0, gWave));
    page->addChild(*dbl(desc, "phase", "Phase", "Wave phase offset.", 0.0, -1000.0, 1000.0, -10.0, 10.0, gWave));
    page->addChild(*dbl(desc, "speed", "Speed", "How fast the wave travels down the trail over time.", 0.15, -20.0, 20.0, -2.0, 2.0, gWave));
    page->addChild(*dbl(desc, "smoke", "Smoke", "Low-frequency turbulence that grows with age.", 0.5, 0.0, 20.0, 0.0, 3.0, gWave));
    page->addChild(*dbl(desc, "smokeScale", "Smoke Scale px", "Size of the turbulence swirls.", 80.0, 1.0, 2000.0, 5.0, 400.0, gWave));
    page->addChild(*dbl(desc, "thickness", "Thickness px", "Base trail width.", 1.5, 0.0, 100.0, 0.0, 12.0, gWave));
    page->addChild(*dbl(desc, "spread", "Spread px", "Extra width that grows with age.", 10.0, 0.0, 400.0, 0.0, 60.0, gWave));

    GroupParamDescriptor* gOut = group(desc, "grpOutput", "Output");
    page->addChild(*dbl(desc, "warmth", "Warmth", "Pushes the trails warm (+) or cool (-).", 0.2, -1.0, 1.0, -1.0, 1.0, gOut));
    page->addChild(*dbl(desc, "intensity", "Intensity", "Trail brightness. 0 bypasses the effect.", 1.0, 0.0, 100.0, 0.0, 10.0, gOut));
    ChoiceParamDescriptor* blend = desc.defineChoiceParam("blend");
    blend->setLabels("Blend", "Blend", "Blend");
    blend->setHint("How the trails combine with the image.");
    blend->appendOption("Add");
    blend->appendOption("Screen");
    blend->appendOption("Trails Only");
    blend->setDefault(0);
    blend->setParent(*gOut);
    page->addChild(*blend);

    GroupParamDescriptor* gDev = group(desc, "grpDevice", "Device");
    page->addChild(*boolp(desc, "useGpu", "Use GPU (CUDA)", "Render on the NVIDIA GPU. Falls back to the CPU automatically if CUDA is unavailable.", true, gDev));
    StringParamDescriptor* status = desc.defineStringParam("status");
    status->setLabels("Status", "Status", "Status");
    status->setHint("Which device is rendering. Details are in %TEMP%\\LightTrails.log.");
    status->setStringType(eStringTypeLabel);
    status->setDefault("");
    status->setEvaluateOnChange(false);
    status->setIsPersistant(false);
    status->setAnimates(false);
    status->setParent(*gDev);
    page->addChild(*status);
}

ImageEffect* LightTrailsFactory::createInstance(OfxImageEffectHandle handle, ContextEnum /*context*/)
{
    return new LightTrailsPlugin(handle);
}

namespace OFX {
namespace Plugin {
void getPluginIDs(OFX::PluginFactoryArray& ids)
{
    static LightTrailsFactory p;
    ids.push_back(&p);
}
} // namespace Plugin
} // namespace OFX
