// ltHost: minimal OFX host (built on the OFX HostSupport library) that loads LightTrails,
// asks it which frames it needs, renders one frame from float RGBA files and writes the result.
// usage: ltHost <frameDir> <W> <H> <numFrames> <t> <out.f32> [param=value ...]
//        set OFX_PLUGIN_PATH to the folder holding LightTrails.ofx.bundle
#include <chrono>
#include <cstdio>
#include <cstdlib>
#include <fstream>
#include <iostream>
#include <map>
#include <memory>
#include <sstream>
#include <string>

#include "ofxCore.h"
#include "ofxImageEffect.h"
#include "ofxhBinary.h"
#include "ofxhPropertySuite.h"
#include "ofxhClip.h"
#include "ofxhParam.h"
#include "ofxhMemory.h"
#include "ofxhImageEffect.h"
#include "ofxhPluginAPICache.h"
#include "ofxhPluginCache.h"
#include "ofxhHost.h"
#include "ofxhImageEffectAPI.h"
#include "hostDemoHostDescriptor.h"
#include "hostDemoEffectInstance.h"
#include "hostDemoClipInstance.h"

extern int gW, gH, gNumFrames;
extern std::string gFrameDir;
extern std::map<std::string, double> gParamOverrides;

#define CHECK(x) do { OfxStatus s_ = (x); if (s_ != kOfxStatOK && s_ != kOfxStatReplyDefault) { fprintf(stderr, "FAIL %s -> %d\n", #x, s_); return 1; } } while (0)

int main(int argc, char** argv)
{
    if (argc < 7) { fprintf(stderr, "usage\n"); return 2; }
    gFrameDir = argv[1]; gW = atoi(argv[2]); gH = atoi(argv[3]); gNumFrames = atoi(argv[4]);
    int t = atoi(argv[5]); std::string outPath = argv[6];
    for (int i = 7; i < argc; ++i) { std::string a = argv[i]; auto e = a.find('='); gParamOverrides[a.substr(0, e)] = atof(a.c_str() + e + 1); }

    OFX::Host::PluginCache::getPluginCache()->setCacheVersion("ltHostV1");
    MyHost::Host host;
    OFX::Host::ImageEffect::PluginCache cache(host);
    cache.registerInCache(*OFX::Host::PluginCache::getPluginCache());
    OFX::Host::PluginCache::getPluginCache()->scanPluginFiles();

    OFX::Host::ImageEffect::ImageEffectPlugin* plugin = cache.getPluginById("com.lighttrails.ofx.LightTrails");
    if (!plugin) { fprintf(stderr, "FAIL plugin not found\n"); cache.dumpToStdOut(); return 1; }
    printf("loaded plugin: %s  group: %s\n", plugin->getDescriptor().getLabel().c_str(),
           plugin->getDescriptor().getPluginGrouping().c_str());

    std::unique_ptr<OFX::Host::ImageEffect::Instance> inst(plugin->createInstance(kOfxImageEffectContextFilter, NULL));
    if (!inst) { fprintf(stderr, "FAIL createInstance\n"); return 1; }
    CHECK(inst->createInstanceAction());
    if (!inst->getClipPreferences()) { fprintf(stderr, "FAIL clip prefs\n"); return 1; }

    // Ask the plugin which source frames it needs for time t (temporal access).
    OFX::Host::ImageEffect::RangeMap needed;
    CHECK(inst->getFrameNeededAction(t, needed));
    for (auto& kv : needed)
        for (auto& r : kv.second) printf("frames needed on %s: %g .. %g\n", kv.first->getName().c_str(), r.min, r.max);

    OfxPointD rs = {1.0, 1.0};
    OfxRectI win = {0, 0, gW, gH};
    OfxRectD roi = {0, 0, (double)gW, (double)gH};
    std::map<OFX::Host::ImageEffect::ClipInstance*, OfxRectD> rois;
    CHECK(inst->getRegionOfInterestAction(t, rs, roi, rois));
    // LT_SEQ_START=n renders frames n..t in order with one instance (sequential playback).
    int t0 = getenv("LT_SEQ_START") ? atoi(getenv("LT_SEQ_START")) : t;
    CHECK(inst->beginRenderAction(t0, t, 1.0, false, rs, true, false));
    for (int f = t0; f <= t; ++f) {
        auto c0 = std::chrono::steady_clock::now();
        CHECK(inst->renderAction(f, kOfxImageFieldBoth, win, rs, true, false, false));
        auto c1 = std::chrono::steady_clock::now();
        printf("frame %d: %.0f ms\n", f, std::chrono::duration<double, std::milli>(c1 - c0).count());
    }
    CHECK(inst->endRenderAction(t0, t, 1.0, false, rs, true, false));

    MyHost::MyClipInstance* out = dynamic_cast<MyHost::MyClipInstance*>(inst->getClip("Output"));
    MyHost::MyImage* img = out->getOutputImage();
    FILE* f = fopen(outPath.c_str(), "wb");
    fwrite(img->pixel(0, 0), 4, size_t(gW) * gH * 4, f);
    fclose(f);
    printf("rendered frame %d -> %s\n", t, outPath.c_str());
    inst.reset();
    OFX::Host::PluginCache::clearPluginCache();
    return 0;
}
