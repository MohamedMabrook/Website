// mock_cuda: a fake NVIDIA driver (libcuda / nvcuda.dll) for testing the CUDA backend without a GPU.
// Kernels run on the CPU through the same per-pixel code, launched block by block like a GPU grid.
// Strict checks: every View in kernel args must point into a live allocation big enough for w*h
// RGBA floats; kernel arg sizes must match the PTX .param declarations; contexts must be balanced;
// all memory must be freed by the time the context is released.
#include "../src/LightTrailsKernels.h"

#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <map>
#include <mutex>
#include <string>

#ifdef _WIN32
#  define EXPORT extern "C" __declspec(dllexport)
#else
#  define EXPORT extern "C" __attribute__((visibility("default")))
#endif

typedef int CUresult;
static std::mutex g_m;
static std::map<unsigned long long, size_t> g_alloc;
static std::string g_ptx;
static int g_ctxDepth = 0, g_launches = 0, g_retained = 0;
static size_t g_peak = 0, g_cur = 0;

static void fail(const char* what)
{
    fprintf(stderr, "MOCK CUDA VIOLATION: %s\n", what);
    fflush(stderr);
    abort();
}

static void checkView(const ltk::View& v, const char* kname, const char* field)
{
    unsigned long long p = (unsigned long long)v.d;
    auto it = g_alloc.upper_bound(p);
    if (it == g_alloc.begin()) { fprintf(stderr, "%s.%s ", kname, field); fail("pointer is not device memory"); }
    --it;
    size_t need = size_t(v.w) * v.h * 16;
    if (p < it->first || p + need > it->first + it->second) { fprintf(stderr, "%s.%s %dx%d ", kname, field, v.w, v.h); fail("view exceeds allocation"); }
}

static size_t ptxParamSize(const char* name)
{
    std::string key = std::string(name) + "_param_0[";
    size_t at = g_ptx.find(key);
    if (at == std::string::npos) return 0;
    return (size_t)atoi(g_ptx.c_str() + at + key.size());
}

struct Fn { int id; const char* name; size_t argSize; };
static Fn g_fns[] = {
    {0, "gKey", sizeof(ltk::KeyArgs)},   {1, "gDown", sizeof(ltk::DownArgs)}, {2, "gBlur", sizeof(ltk::BlurArgs)},
    {3, "gGrad", sizeof(ltk::GradArgs)}, {4, "gSolve", sizeof(ltk::SolveArgs)}, {5, "gPrep", sizeof(ltk::PrepArgs)},
    {6, "gSmoke", sizeof(ltk::SmokeArgs)}, {7, "gSmear", sizeof(ltk::SmearArgs)}, {8, "gComp", sizeof(ltk::CompArgs)},
};

EXPORT CUresult cuInit(unsigned) { return 0; }
EXPORT CUresult cuDeviceGetCount(int* n) { *n = 1; return 0; }
EXPORT CUresult cuDeviceGet(int* d, int i) { *d = i; return 0; }
EXPORT CUresult cuDeviceGetName(char* s, int n, int) { snprintf(s, n, "Mock RTX"); return 0; }
EXPORT CUresult cuDevicePrimaryCtxRetain(void** c, int) { *c = (void*)0x1234; g_retained++; return 0; }
EXPORT CUresult cuDevicePrimaryCtxRelease(int)
{
    g_retained--;
    fprintf(stderr, "mock: context released. launches=%d peak device MB=%.1f live allocations=%zu\n",
            g_launches, g_peak / 1048576.0, g_alloc.size());
    if (!g_alloc.empty()) fail("device memory leaked");
    return 0;
}
EXPORT CUresult cuCtxPushCurrent_v2(void* c) { if (c != (void*)0x1234) fail("bad ctx"); g_ctxDepth++; return 0; }
EXPORT CUresult cuCtxPopCurrent_v2(void** c) { if (g_ctxDepth <= 0) fail("pop without push"); g_ctxDepth--; if (c) *c = (void*)0x1234; return 0; }
EXPORT CUresult cuModuleLoadDataEx(void** m, const void* img, unsigned, int*, void**)
{
    g_ptx = (const char*)img;
    if (g_ptx.find(".target sm_") == std::string::npos) fail("module image is not PTX");
    *m = (void*)0x5678;
    return 0;
}
EXPORT CUresult cuModuleUnload(void*) { return 0; }
EXPORT CUresult cuModuleGetFunction(void** f, void*, const char* name)
{
    for (auto& fn : g_fns)
        if (!strcmp(fn.name, name)) {
            if (g_ptx.find(std::string(".entry ") + name + "(") == std::string::npos) fail("function not in PTX");
            if (ptxParamSize(name) != fn.argSize) { fprintf(stderr, "%s ptx=%zu host=%zu ", name, ptxParamSize(name), fn.argSize); fail("arg size mismatch"); }
            *f = &fn;
            return 0;
        }
    return 500; // CUDA_ERROR_NOT_FOUND
}
EXPORT CUresult cuMemAlloc_v2(unsigned long long* p, size_t n)
{
    std::lock_guard<std::mutex> l(g_m);
    if (g_ctxDepth <= 0) fail("alloc without current context");
    void* m = calloc(1, n);
    *p = (unsigned long long)m;
    g_alloc[*p] = n;
    g_cur += n; if (g_cur > g_peak) g_peak = g_cur;
    return 0;
}
EXPORT CUresult cuMemFree_v2(unsigned long long p)
{
    std::lock_guard<std::mutex> l(g_m);
    auto it = g_alloc.find(p);
    if (it == g_alloc.end()) fail("free of unknown pointer");
    g_cur -= it->second;
    g_alloc.erase(it);
    free((void*)p);
    return 0;
}
EXPORT CUresult cuMemcpyHtoD_v2(unsigned long long d, const void* s, size_t n)
{
    auto it = g_alloc.find(d);
    if (it == g_alloc.end() || n > it->second) fail("HtoD out of range");
    memcpy((void*)d, s, n);
    return 0;
}
EXPORT CUresult cuMemcpyDtoH_v2(void* d, unsigned long long s, size_t n)
{
    auto it = g_alloc.find(s);
    if (it == g_alloc.end() || n > it->second) fail("DtoH out of range");
    memcpy(d, (void*)s, n);
    return 0;
}

template <typename A, typename F>
static void grid(void** params, unsigned gx, unsigned gy, unsigned bx, unsigned by, int W, int H, F f)
{
    const A& a = *static_cast<const A*>(params[0]);
    for (unsigned by_ = 0; by_ < gy; ++by_)
        for (unsigned bx_ = 0; bx_ < gx; ++bx_)
            for (unsigned ty = 0; ty < by; ++ty)
                for (unsigned tx = 0; tx < bx; ++tx) {
                    int x = bx_ * bx + tx, y = by_ * by + ty;
                    if (x < W && y < H) f(x, y, a);
                }
}

EXPORT CUresult cuLaunchKernel(void* f, unsigned gx, unsigned gy, unsigned gz, unsigned bx, unsigned by, unsigned bz,
                               unsigned shm, void* stream, void** params, void** extra)
{
    if (g_ctxDepth <= 0) fail("launch without current context");
    if (gz != 1 || bz != 1 || shm != 0 || extra) fail("unexpected launch config");
    if (bx * by > 1024) fail("block too large");
    g_launches++;
    Fn* fn = (Fn*)f;
    switch (fn->id) {
#define V(T, field) checkView(static_cast<const T*>(params[0])->field, fn->name, #field)
        case 0: { V(ltk::KeyArgs, src); V(ltk::KeyArgs, dst); auto& a = *(ltk::KeyArgs*)params[0];
                  grid<ltk::KeyArgs>(params, gx, gy, bx, by, a.dst.w, a.dst.h, ltk::kKey); break; }
        case 1: { V(ltk::DownArgs, src); V(ltk::DownArgs, dst); auto& a = *(ltk::DownArgs*)params[0];
                  grid<ltk::DownArgs>(params, gx, gy, bx, by, a.dst.w, a.dst.h, ltk::kDown); break; }
        case 2: { V(ltk::BlurArgs, src); V(ltk::BlurArgs, dst); auto& a = *(ltk::BlurArgs*)params[0];
                  if (a.src.d == a.dst.d) fail("blur in place");
                  grid<ltk::BlurArgs>(params, gx, gy, bx, by, a.dst.w, a.dst.h, ltk::kBlur); break; }
        case 3: { V(ltk::GradArgs, bo); V(ltk::GradArgs, bn); V(ltk::GradArgs, fl); V(ltk::GradArgs, dst); auto& a = *(ltk::GradArgs*)params[0];
                  grid<ltk::GradArgs>(params, gx, gy, bx, by, a.dst.w, a.dst.h, ltk::kGrad); break; }
        case 4: { V(ltk::SolveArgs, p1); V(ltk::SolveArgs, p2); V(ltk::SolveArgs, fl); V(ltk::SolveArgs, dst); auto& a = *(ltk::SolveArgs*)params[0];
                  if (a.useFlow && a.fl.d == a.dst.d) fail("solve in place");
                  grid<ltk::SolveArgs>(params, gx, gy, bx, by, a.dst.w, a.dst.h, ltk::kSolve); break; }
        case 5: { V(ltk::PrepArgs, fl); V(ltk::PrepArgs, bo); V(ltk::PrepArgs, bn); V(ltk::PrepArgs, dst); auto& a = *(ltk::PrepArgs*)params[0];
                  grid<ltk::PrepArgs>(params, gx, gy, bx, by, a.dst.w, a.dst.h, ltk::kPrep); break; }
        case 6: { V(ltk::SmokeArgs, dst); auto& a = *(ltk::SmokeArgs*)params[0];
                  grid<ltk::SmokeArgs>(params, gx, gy, bx, by, a.dst.w, a.dst.h, ltk::kSmoke); break; }
        case 7: { V(ltk::SmearArgs, acc); V(ltk::SmearArgs, hk); auto& a = *(ltk::SmearArgs*)params[0];
                  if (a.useFs) V(ltk::SmearArgs, fs);
                  if (a.useSmoke) { V(ltk::SmearArgs, g0); V(ltk::SmearArgs, g1); }
                  if (a.acc.d == a.hk.d) fail("smear acc aliases hk");
                  grid<ltk::SmearArgs>(params, gx, gy, bx, by, a.acc.w, a.acc.h, ltk::kSmear); break; }
        case 8: { V(ltk::CompArgs, src); V(ltk::CompArgs, acc); V(ltk::CompArgs, dst); auto& a = *(ltk::CompArgs*)params[0];
                  grid<ltk::CompArgs>(params, gx, gy, bx, by, a.dst.w, a.dst.h, ltk::kComp); break; }
#undef V
        default: fail("unknown function");
    }
    return 0;
}
EXPORT CUresult cuCtxSynchronize() { return 0; }
EXPORT CUresult cuGetErrorString(CUresult, const char** s) { *s = "mock error"; return 0; }
