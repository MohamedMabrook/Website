# Writes the same synthetic shot the Fuse harness uses (y-up rows) as raw float RGBA.
import sys, os, numpy as np
from PIL import Image
from scipy.ndimage import map_coordinates
ref_path, outdir, pan, n = sys.argv[1], sys.argv[2], float(sys.argv[3]), int(sys.argv[4])
ref = np.asarray(Image.open(ref_path).convert('RGB').resize((1440, 675), Image.LANCZOS)).astype(np.float32) / 255
H, W, _ = ref.shape
yy, xx = np.mgrid[0:H, 0:W].astype(np.float32)
for i in range(n):
    z = 1 + 0.004*i; ox = pan*i + 10*np.sin(i*0.4); oy = 6*np.sin(i*0.3)
    sx = (xx - W/2 - ox)/z + W/2; sy = (yy - H/2 - oy)/z + H/2
    f = np.stack([map_coordinates(ref[...,c], [sy, sx], order=1, mode='nearest') for c in range(3)] + [np.ones_like(xx)], -1)
    np.ascontiguousarray(f[::-1]).astype(np.float32).tofile(os.path.join(outdir, 'frame_%03d.f32' % i))
print(W, H)
