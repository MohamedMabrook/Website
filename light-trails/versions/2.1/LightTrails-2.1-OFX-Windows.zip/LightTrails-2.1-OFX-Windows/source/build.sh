#!/usr/bin/env bash
# Builds LightTrails.ofx. "windows" (default): Win64 via MinGW-w64. "linux": native, for tests.
# sdkpatch/ holds the OFX support library with CUDA render arguments added.
# Needs: clang (CUDA -> PTX), MinGW-w64 posix toolchain, OFX SDK at OFX_Release_1_4_TAG.
# Optional: PTXAS=/path/to/ptxas to verify the PTX for real GPU architectures.
set -euo pipefail
cd "$(dirname "$0")"
OFX=${OFX_SDK:-../ofxsdk/openfx14}
GEN=build/gen
mkdir -p "$GEN"

# 1. CUDA kernels -> PTX (ISA 6.3 / sm_75: the driver JIT-compiles it for any newer GPU)
clang++ -x cuda --cuda-device-only --cuda-gpu-arch=sm_75 -nocudainc -nocudalib -O3 -std=c++14 \
  -Isrc -S -o "$GEN/LightTrails.ptx" src/LightTrailsKernels.cu
if [ -n "${PTXAS:-}" ]; then
  for a in sm_75 sm_86 sm_89 sm_90; do "$PTXAS" -arch=$a "$GEN/LightTrails.ptx" -o /dev/null; done
  echo "ptxas verified sm_75 sm_86 sm_89 sm_90"
fi
python3 - "$GEN/LightTrails.ptx" "$GEN/LightTrails_ptx.h" <<'PY'
import sys
ptx = open(sys.argv[1]).read()
assert ')PTX"' not in ptx
open(sys.argv[2], 'w').write('// generated from LightTrailsKernels.cu\nstatic const char kLightTrailsPtx[] = R"PTX(' + ptx + ')PTX";\n')
PY

# 2. Plugin
SRC="src/LightTrailsPlugin.cpp src/LightTrailsCore.cpp src/LightTrailsCuda.cpp \
  $OFX/Support/Library/ofxsCore.cpp sdkpatch/ofxsImageEffect.cpp $OFX/Support/Library/ofxsInteract.cpp \
  $OFX/Support/Library/ofxsLog.cpp $OFX/Support/Library/ofxsMultiThread.cpp $OFX/Support/Library/ofxsParams.cpp \
  $OFX/Support/Library/ofxsProperty.cpp $OFX/Support/Library/ofxsPropertyValidation.cpp"
INC="-Isdkpatch -Isrc -I$GEN -I$OFX/include -I$OFX/Support/include -I$OFX/Support/Library"
FLAGS="-O3 -std=gnu++14 -Wno-deprecated -DNDEBUG -fvisibility=hidden"
TARGET=${1:-windows}
if [ "$TARGET" = linux ]; then
  OUT=build/linux/LightTrails.ofx.bundle/Contents/Linux-x86-64
  mkdir -p "$OUT"
  g++ $FLAGS -fPIC -shared -pthread $INC $SRC -o "$OUT/LightTrails.ofx" -ldl
else
  OUT=build/windows/LightTrails.ofx.bundle/Contents/Win64
  mkdir -p "$OUT"
  x86_64-w64-mingw32-g++-posix $FLAGS -shared -march=x86-64-v2 $INC $SRC -o "$OUT/LightTrails.ofx" \
    -static -static-libgcc -static-libstdc++ -Wl,--no-insert-timestamp -s
fi
echo "built $OUT/LightTrails.ofx"
