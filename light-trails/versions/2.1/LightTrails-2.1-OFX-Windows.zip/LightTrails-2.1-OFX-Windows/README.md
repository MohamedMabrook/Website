# Light Trails 2.1: OpenFX for DaVinci Resolve (Windows, NVIDIA GPU)

Wavy, smoky trails from the hottest white lights. 2.1 is the reference look: lamps at the sides of frame streak inward on a still shot.

## What changed from 2.0

- **Trails on still lights.** 2.0 built trails only from where lights had moved. Lamps that don't move just got brighter, because every echo stacked on top of the lamp. The new **Direction** setting grows a streak from every hot point:
  - **Inward** (default): lamps at the sides trail toward the middle.
  - **Outward**, **Up**, or a chosen **Angle**.
  - **Follow Motion**: the old behavior, for moving lights.
- **Much lighter.** Inward, Outward, Up and Angle use only the current frame: no previous frames, no motion solving. In the test harness, Medium renders about 30× faster than 2.0's Follow Motion, and Intensity, Warmth and Blend changes recomposite in about 25 ms.
- **Crash hardening.** 2.0 could ask Resolve for previous frames it hadn't declared. That happened after its frame cache reset, which it did on any tiny change in the image, and it's the likely cause of the crash when you changed Decay. In 2.1:
  - **Follow Motion declares its whole frame window,** and the static directions use no other frames at all.
  - **The cache tolerates grain and noise,** so it no longer resets on tiny changes.
  - **Resolve's GPU buffers are size-checked before use.** A bad buffer gives an error instead of an out-of-bounds write.
  - **Every render is logged first** to `%TEMP%\LightTrails.log`, so after a crash the last line shows what was running.

## Controls

- **Quality**: Low, Medium, High or Final. **Intensity**.
- **Highlights**: **Threshold**, **Softness**, **Include Colored Lights**, **Show Mask**.
- **Trail**
  - **Direction**.
  - **Length**: % of frame width.
  - **Decay**: how much of the tail survives.
  - **Rise**: tilt for Inward and Outward.
  - **Angle**: direction for Angle mode.
  - **Motion Frames**: Follow Motion only.
- **Look**: **Wave**, **Wave Frequency**, **Wave Speed**, **Smoke**, **Width**, **Warmth**, **Blend**.
- **Depth**: same as 2.0.

## Install

Close Resolve, right-click `install.bat` and choose **Run as administrator**. Or use the auto-installer on the Light Trails page.
